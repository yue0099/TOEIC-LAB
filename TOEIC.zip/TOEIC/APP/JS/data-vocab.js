const vocabList = [
  {
    text: "acceptance",
    meaning: "接受；答應；認可",
    example: "Now that you have indicated your acceptance of our offer, I will prepare the contract for you to sign.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "address",
    meaning: "對～說話；向～演講；在（信封等上）寫地址",
    example: "The speaker addressed the audience.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "adjourn",
    meaning: "使中止；休（會）",
    example: "I think we should adjourn the meeting and get back to work.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "admit",
    meaning: "承認；准許進入",
    example: "Only ticket-holders were admitted.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "advertisement",
    meaning: "（平面媒體、電視、廣播及網路上的）廣告；宣傳",
    example: "I saw an advertisement for a new line of cleaning products.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "affiliate",
    meaning: "分支機構；分會；支部",
    example: "The organization is an affiliate of the Red Cross.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "afford",
    meaning: "負擔得起；給予",
    example: "I don't think we can afford to hire a new employee until we get more clients.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "agenda",
    meaning: "議程；討論主題",
    example: "We cannot discuss that today because it's not on the agenda.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "aggressive",
    meaning: "積極的；好攻擊的",
    example: "New companies have to be aggressive in promoting their products in order to break into the market.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "agreement",
    meaning: "協定；協議；同意；一致",
    example: "The two countries signed a trade agreement.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "amend",
    meaning: "修改；修訂（文件、法案）",
    example: "Can we amend this part of the contract before we sign?",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "anxious",
    meaning: "熱切的；焦慮的；擔憂的",
    example: "We are anxious to talk about it as soon as possible.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "arrangement",
    meaning: "協議；安排；排列",
    example: "We have a special arrangement with the supplier, so we don't have to pay immediately.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "as opposed to",
    meaning: "與～相對",
    example: "We'll sell to wealthy consumers as opposed to middle- or low-income buyers.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "assume",
    meaning: "認為；假定；假裝",
    example: "I assume everyone knows why I have called this meeting.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "assurance",
    meaning: "保證；確保",
    example: "The salesman gave his assurance that the price would not go up.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "attend",
    meaning: "參加；出席",
    example: "Five hundred businesspeople attended the conference.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "attract",
    meaning: "吸引；引起",
    example: "The conference attracted businesspeople from all over the world.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "auction",
    meaning: "拍賣",
    example: "Sotheby's announced that they would be selling a Monet painting in the May auction.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "avoid",
    meaning: "避免；迴避",
    example: "Try to avoid talking about the price until the very end.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "bargain",
    meaning: "議價；交易；特價品",
    example: "They are bargaining over the price right now.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "bid",
    meaning: "出價；喊價；投標",
    example: "Our company won the bid.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "binding",
    meaning: "有約束力的；必須遵守的",
    example: "The contract is legally binding.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "boardroom",
    meaning: "會議室",
    example: "Today's meeting will be held in the boardroom.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "boom",
    meaning: "景氣好；繁榮",
    example: "During the 90s, the U.S. economy boomed in large part because of the expansion of the Internet.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "brainstorming",
    meaning: "腦力激盪",
    example: "The initial brainstorming should run without judgment.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "brand",
    meaning: "品牌；商標",
    example: "There is a new brand on the market, and we need to discuss how it will affect us.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "breach",
    meaning: "違約；違反；侵害（法律、合約等）",
    example: "If you raise the price, that will be a breach of our contract.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "cancellation",
    meaning: "取消",
    example: "We are sorry to inform you of the cancellation of the conference.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "characteristic",
    meaning: "特色；特徵（多用複數）",
    example: "Explain the characteristics of the product to the customer.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "charge",
    meaning: "索價；費用",
    example: "How much are we going to charge for this?",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "clause",
    meaning: "條款",
    example: "I want a clause put in the contract that says I will also get five percent of the profits.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "come up with",
    meaning: "（針對問題等）想出；提供",
    example: "Let's come up with some ideas to solve this problem.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "commercial",
    meaning: "（廣播或電視的）廣告；商業的；營利的",
    example: "Our new commercial will be shown on TV tonight.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "compare",
    meaning: "比較",
    example: "Customers will always compare your product with those of other companies.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "competition",
    meaning: "競爭；角逐",
    example: "The two stores were in competition for customers.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "compromise",
    meaning: "妥協；折衷",
    example: "The two sides could not reach a compromise, so the meeting ended without resolving anything.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "concede",
    meaning: "承認；對～讓步",
    example: "After five years, the company had to concede that the project had been a failure.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "conclude",
    meaning: "結束（會議、演講）；作結論；推論",
    example: "Well, if no one has anything else to say, let's conclude the meeting.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "confidential",
    meaning: "秘密的；機密的",
    example: "Please remember that anything we discuss during this meeting is confidential.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "consequence",
    meaning: "結果；後果；重要（性）",
    example: "The consequence of not planning well is a business that does badly.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "consider",
    meaning: "考慮",
    example: "Would you consider lowering the price?",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "consumer",
    meaning: "消費者",
    example: "Many companies are trying to get a slice of China's consumer market.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "contract",
    meaning: "契約；合同",
    example: "Sean had to sign a contract when he began his job.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "convince",
    meaning: "說服；使信服",
    example: "You must convince the customer that your product is what he or she wants.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "cover",
    meaning: "包含；包括",
    example: "A good business plan should cover everything.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "credential",
    meaning: "憑據；證書（常用複數形）",
    example: "All media visiting the show must have authorized credentials.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "demonstrate",
    meaning: "示範；證明",
    example: "Customers are more likely to buy if you demonstrate the product for them.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "designate",
    meaning: "標明；指示；任命",
    example: "We voted last night, and designated Tom the spokesman for our group.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "detach",
    meaning: "分開；拆卸；使分離",
    example: "Please detach the white part of the application form.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "determine",
    meaning: "決定；確定",
    example: "We have determined both our market and price.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "develop",
    meaning: "發展；開發；培養",
    example: "We need to develop a strong sales team.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "direct marketing",
    meaning: "直效行銷",
    example: "Using direct marketing, we were able to advertise our products to the people most likely to buy them.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "direct-response",
    meaning: "直接回應的；直效的",
    example: "Direct-response advertising is very popular on the Internet.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "distribution",
    meaning: "分配；配銷；流通",
    example: "We are planning for global distribution of our product.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "downsize",
    meaning: "縮編",
    example: "With the economy having problems, a lot of companies have been forced to downsize to stay competitive.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "enclose",
    meaning: "把（公文、票據等）封入；附上",
    example: "Please enclose your payment in the envelope.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "enterprise",
    meaning: "事業；企業；公司",
    example: "The city government offered grants in hopes of stimulating local enterprises.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "entrepreneur",
    meaning: "企業家；事業家",
    example: "Donald Trump is one of the most famous entrepreneurs in the world.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "establish",
    meaning: "創立；建立",
    example: "It isn't easy to establish a new business.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "evaluate",
    meaning: "對～評價；評估",
    example: "It will help you make the sale if you first evaluate the mood of the customer.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "fad",
    meaning: "（一時的）潮流；趨勢",
    example: "A good businessperson will know all the latest fads.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "firm",
    meaning: "公司",
    example: "David has set up a firm of his own.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "franchise",
    meaning: "經銷權；加盟",
    example: "The largest fast-food chains operate on the franchise system.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "gather",
    meaning: "聚集；集會；收集",
    example: "Thousands of managers are gathering in Taipei for the trade fair.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "go over",
    meaning: "察看；重溫",
    example: "Before signing any contract, you should go over it with a lawyer.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "headquarters",
    meaning: "總部",
    example: "The CEO promised to hold a press conference at the company headquarters in Chicago.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "hold",
    meaning: "舉行；舉辦",
    example: "The meeting was held in Taipei.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "hook",
    meaning: "銷售手法",
    example: "The marketing hook for the movie The Blair Witch Project was making people believe that what happened was real and not acted.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "inevitable",
    meaning: "不可避免的；必然（發生）的",
    example: "The series of bad decisions led to the inevitable failure of the business.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "legitimate",
    meaning: "合法的；正當的",
    example: "I can assure you that it is a legitimate business.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "lengthy",
    meaning: "長時間的；冗長的",
    example: "It was a lengthy meeting, but a good one.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "location",
    meaning: "場所；位置",
    example: "We need to find a good location for the conference.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "market",
    meaning: "銷售；市場",
    example: "They are marketing their product toward young females.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "matter",
    meaning: "事情；主題；考量",
    example: "There is another matter I would like to discuss.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "merchandise",
    meaning: "商品；買賣；經營",
    example: "The contract states that our merchandise must be placed at the front of the store.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "mission",
    meaning: "任務；使命",
    example: "It is the company's mission to outsell its competitors by the end of the year.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "negotiate",
    meaning: "談判；協商",
    example: "It is difficult to negotiate with that salesperson.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "objection",
    meaning: "反對；異議",
    example: "Mr. Lee had an objection to the client's opinion.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "obligate",
    meaning: "使（某人）遵守義務或責任",
    example: "You are obligated to buy our products for the next three years.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "offer",
    meaning: "報價；出價；提供；提議",
    example: "Is that your final offer? I was hoping you might lower the price more than that.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "offset",
    meaning: "抵消；補償",
    example: "The losses incurred by the luxury car division in the last quarter were offset by the increase in the sales of compacts.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "open to",
    meaning: "需要；開放～的空間；不限",
    example: "This proposal is open to discussion.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "party",
    meaning: "（契約）當事人；一方",
    example: "Both parties need to sign the contract.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "periodically",
    meaning: "有時；偶爾；週期性地",
    example: "We have meetings periodically, but not on a fixed schedule.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "persuasion",
    meaning: "說服；說服力",
    example: "It took a lot of persuasion to get her to sign.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "presentation",
    meaning: "簡報；介紹",
    example: "We've heard enough of your sales presentation. Please come to the point.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "primarily",
    meaning: "主要地；最初",
    example: "Our customers are primarily women, but many men also buy our products.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "productive",
    meaning: "具建設性的；有生產力；多產的",
    example: "I thought the discussion was very productive.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "progress",
    meaning: "進展；進步（不可數）",
    example: "We didn't make much progress at the last meeting, so I hope we can be more successful this time.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "promise",
    meaning: "保證；諾言",
    example: "Never promise the customer anything!",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "protect",
    meaning: "保護",
    example: "The contract protects us both from any misunderstandings later.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "register",
    meaning: "登錄；登記；註冊",
    example: "You must register the business before you can start selling anything.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "reputation",
    meaning: "評價；聲望",
    example: "Customers will trust a company with a good reputation.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "research",
    meaning: "研究；調查；探索",
    example: "This business report needs a lot of research.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "retail",
    meaning: "零售（的）",
    example: "December retail sales have jumped fifty percent.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "risk",
    meaning: "風險；危險",
    example: "Starting a new business has its risks, but also many rewards.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "satisfaction",
    meaning: "滿意；滿足；愉快",
    example: "Customer satisfaction is very important.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "satisfy",
    meaning: "履行（契約）；清償（債務）",
    example: "You must satisfy the contract.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "see eye to eye",
    meaning: "意見一致",
    example: "After talking to Amy for over an hour, I can safely say we see eye to eye on this issue.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "session",
    meaning: "會期；一段時間；集會；講習會",
    example: "The presentation will be given in two sessions: one in the morning, and the other in the afternoon.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "signature",
    meaning: "簽名；署名",
    example: "Please put your signature at the bottom of the page.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "solve",
    meaning: "解決；找到答案",
    example: "You can solve many problems by discussing them with coworkers.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "specific",
    meaning: "特有的；明確的",
    example: "Every customer has a specific need.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "stand out",
    meaning: "引人注目；脫穎而出",
    example: "We need to have a presentation that stands out from the crowd.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "strategy",
    meaning: "策略；戰略",
    example: "We need to think very carefully about our marketing strategy for this product.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "strong",
    meaning: "強硬的；佔優勢的；激烈的",
    example: "They have a very strong position in the negotiations.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "submit",
    meaning: "提交；呈遞",
    example: "Please submit your report to the secretary by May 10th.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "take place",
    meaning: "發生；舉行",
    example: "The conference will take place in Houston from March 2nd to March 4th.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "take the consequences",
    meaning: "承擔後果",
    example: "If the deal falls through, I'll take the consequences.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "terminate",
    meaning: "使結束；使終止",
    example: "They can't terminate the contract until next year.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "upcoming",
    meaning: "即將來臨的",
    example: "We look forward to your participation at the upcoming conference.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "variety",
    meaning: "變化；各式各樣的事物",
    example: "We have a variety of products that would suit you.",
    category: "商務溝通",
    importance: 3
  },
  {
    text: "as a result of",
    meaning: "由於",
    example: "The company's quality standards went down as a result of the increase in new, untrained workers.",
    category: "製造業",
    importance: 3
  },
  {
    text: "assemble",
    meaning: "配裝；組裝",
    example: "The parts are made in America, but the final product is assembled in China.",
    category: "製造業",
    importance: 3
  },
  {
    text: "assembly line",
    meaning: "生產線",
    example: "Our assembly line is capable of producing 1,000 units per hour.",
    category: "製造業",
    importance: 3
  },
  {
    text: "automated",
    meaning: "自動化的",
    example: "The production process is now fully automated.",
    category: "製造業",
    importance: 3
  },
  {
    text: "batch",
    meaning: "一批（生產量）",
    example: "The problems had all been fixed by the third batch of computer monitors.",
    category: "製造業",
    importance: 3
  },
  {
    text: "circumstance",
    meaning: "情況；環境",
    example: "Under no circumstances should items go out if they have any problems.",
    category: "製造業",
    importance: 3
  },
  {
    text: "collaboration",
    meaning: "合作；協力",
    example: "We can choose to work in collaboration with another company or on our own.",
    category: "製造業",
    importance: 3
  },
  {
    text: "component",
    meaning: "零件；組件",
    example: "The hard drive is a vital component of any computer.",
    category: "製造業",
    importance: 3
  },
  {
    text: "concentrate",
    meaning: "集中注意力；全神貫注",
    example: "You have to concentrate very hard to make sure that you don't miss any problems.",
    category: "製造業",
    importance: 3
  },
  {
    text: "condition",
    meaning: "狀況；地位；條件",
    example: "We want everything to go out in perfect condition.",
    category: "製造業",
    importance: 3
  },
  {
    text: "conform",
    meaning: "符合；配合；遵守",
    example: "The finished product must conform to industry standards.",
    category: "製造業",
    importance: 3
  },
  {
    text: "conveyor belt",
    meaning: "（生產線、機場行李等的）輸送帶",
    example: "The conveyor belts need to be replaced every three years.",
    category: "製造業",
    importance: 3
  },
  {
    text: "customize",
    meaning: "訂做",
    example: "The system allows us to customize each product for our customers.",
    category: "製造業",
    importance: 3
  },
  {
    text: "deadline",
    meaning: "截止日期",
    example: "We have to meet our deadline for this project.",
    category: "製造業",
    importance: 3
  },
  {
    text: "decade",
    meaning: "十年",
    example: "We have been running this product line for almost a decade now.",
    category: "製造業",
    importance: 3
  },
  {
    text: "defect",
    meaning: "缺陷；瑕疵；缺點",
    example: "If an item has even the smallest defect, we must not send it out.",
    category: "製造業",
    importance: 3
  },
  {
    text: "device",
    meaning: "設備；儀器；裝置",
    example: "If the device senses smoke, it sets off an alarm.",
    category: "製造業",
    importance: 3
  },
  {
    text: "dimension",
    meaning: "尺寸；規模",
    example: "The dimensions of the pedal were reduced to fit the new bicycle design.",
    category: "製造業",
    importance: 3
  },
  {
    text: "disruption",
    meaning: "干擾；中斷",
    example: "The mistake caused a big disruption to the order schedule.",
    category: "製造業",
    importance: 3
  },
  {
    text: "durability",
    meaning: "耐久性；耐用性",
    example: "For the past fifty years, this brand of jeans has been known for its durability.",
    category: "製造業",
    importance: 3
  },
  {
    text: "electronics",
    meaning: "電子產品",
    example: "China is the current construction hotspot for Taiwanese electronics factories.",
    category: "製造業",
    importance: 3
  },
  {
    text: "encounter",
    meaning: "遇到（困難、危險等）",
    example: "You will encounter many different types of problems in the sample testing.",
    category: "製造業",
    importance: 3
  },
  {
    text: "enforcement",
    meaning: "強制；執行",
    example: "Quality-control standards are worthless without proper enforcement within the factory.",
    category: "製造業",
    importance: 3
  },
  {
    text: "enhance",
    meaning: "增加；提高",
    example: "The new system is meant to enhance the speed of production.",
    category: "製造業",
    importance: 3
  },
  {
    text: "epidemic",
    meaning: "普遍的；流行的",
    example: "Due to epidemic defects, all of the MP3 players were returned to the factory.",
    category: "製造業",
    importance: 3
  },
  {
    text: "examine",
    meaning: "仔細檢查；檢測；測驗",
    example: "We examine the parts to make sure that they have been made well.",
    category: "製造業",
    importance: 3
  },
  {
    text: "experiment",
    meaning: "試驗；實驗",
    example: "We are experimenting with ways to improve the quality of our product.",
    category: "製造業",
    importance: 3
  },
  {
    text: "facility",
    meaning: "設備",
    example: "The new facility is twice as large as the old facility.",
    category: "製造業",
    importance: 3
  },
  {
    text: "find out",
    meaning: "發現；找出",
    example: "We need to find out what the problem is so we can fix it.",
    category: "製造業",
    importance: 3
  },
  {
    text: "fire extinguisher",
    meaning: "滅火器",
    example: "All the fire extinguishers have to be inspected every six months.",
    category: "製造業",
    importance: 3
  },
  {
    text: "fluctuate",
    meaning: "波動；變動",
    example: "Quality can go up and down just a little, but it would be better if it didn't fluctuate at all.",
    category: "製造業",
    importance: 3
  },
  {
    text: "fraction",
    meaning: "小部分；片段",
    example: "Only a small fraction of our employees have a college degree.",
    category: "製造業",
    importance: 3
  },
  {
    text: "gadget",
    meaning: "小機件",
    example: "Our factory produces kitchen gadgets and appliances.",
    category: "製造業",
    importance: 3
  },
  {
    text: "garment",
    meaning: "衣服；服裝",
    example: "We are very happy with the way our dresses and other garments look.",
    category: "製造業",
    importance: 3
  },
  {
    text: "glitch",
    meaning: "（設備、機器等的）小故障；小毛病",
    example: "It looks like all the glitches were corrected.",
    category: "製造業",
    importance: 3
  },
  {
    text: "goods",
    meaning: "商品；貨物",
    example: "Moving goods by train is cheaper than moving them by truck.",
    category: "製造業",
    importance: 3
  },
  {
    text: "hamper",
    meaning: "阻礙；妨礙",
    example: "Our efforts are being hampered by a shortage of trained staff.",
    category: "製造業",
    importance: 3
  },
  {
    text: "high-tech industry",
    meaning: "高科技產業",
    example: "Taiwan's strength is in high-tech industry.",
    category: "製造業",
    importance: 3
  },
  {
    text: "in good condition",
    meaning: "狀況良好",
    example: "This machine is still in good condition.",
    category: "製造業",
    importance: 3
  },
  {
    text: "in stock",
    meaning: "有存貨的；買得到的",
    example: "We have lots of paper in stock.",
    category: "製造業",
    importance: 3
  },
  {
    text: "indicator",
    meaning: "指標；指針",
    example: "Price is not always an indicator of quality.",
    category: "製造業",
    importance: 3
  },
  {
    text: "industry",
    meaning: "工業；行業",
    example: "America still dominates the film industry around the world.",
    category: "製造業",
    importance: 3
  },
  {
    text: "in-house",
    meaning: "內部完成而不假外力地；內部的",
    example: "All of the marketing for our products is done in-house.",
    category: "製造業",
    importance: 3
  },
  {
    text: "inspect",
    meaning: "仔細檢查；稽查",
    example: "We inspect every item before it goes out.",
    category: "製造業",
    importance: 3
  },
  {
    text: "install",
    meaning: "安裝；設置",
    example: "A safety cord was installed beside the assembly line.",
    category: "製造業",
    importance: 3
  },
  {
    text: "inventory",
    meaning: "庫存；存貨；物品清單",
    example: "I have taken inventory to see what supplies we need to order.",
    category: "製造業",
    importance: 3
  },
  {
    text: "labor-intensive",
    meaning: "勞力密集的",
    example: "Many major companies have relegated labor-intensive jobs to China.",
    category: "製造業",
    importance: 3
  },
  {
    text: "launch",
    meaning: "開辦；產品上市",
    example: "The product line will be launched in time for Christmas.",
    category: "製造業",
    importance: 3
  },
  {
    text: "life-test",
    meaning: "測試～的使用壽命",
    example: "We need to life-test the samples to determine their durability.",
    category: "製造業",
    importance: 3
  },
  {
    text: "logical",
    meaning: "合邏輯的；合理的",
    example: "Hiring temporary staff is the logical thing to do.",
    category: "製造業",
    importance: 3
  },
  {
    text: "machinery",
    meaning: "機械裝置",
    example: "Most of the machinery is over twenty years old.",
    category: "製造業",
    importance: 3
  },
  {
    text: "maintenance",
    meaning: "維修；保養",
    example: "All maintenance is done at night when the assembly line is not running.",
    category: "製造業",
    importance: 3
  },
  {
    text: "malfunction",
    meaning: "故障；機能失常",
    example: "Even the tiniest foreign object can cause a malfunction.",
    category: "製造業",
    importance: 3
  },
  {
    text: "manufacturer",
    meaning: "製造業者；廠商",
    example: "Our company is the largest bolt manufacturer in the United States.",
    category: "製造業",
    importance: 3
  },
  {
    text: "mass production",
    meaning: "大量生產",
    example: "The machinery that is needed to set up a mass production line is too expensive.",
    category: "製造業",
    importance: 3
  },
  {
    text: "mechanic",
    meaning: "技工",
    example: "The senior mechanic has ten years of experience with this equipment.",
    category: "製造業",
    importance: 3
  },
  {
    text: "model",
    meaning: "模型；型號",
    example: "The newest model has a touchscreen and longer battery life.",
    category: "製造業",
    importance: 3
  },
  {
    text: "offshoring",
    meaning: "產業外移",
    example: "Offshoring in the IT industry set off India's recent economic boom.",
    category: "製造業",
    importance: 3
  },
  {
    text: "on-site",
    meaning: "現場的；在現場",
    example: "We're going to conduct an on-site inspection.",
    category: "製造業",
    importance: 3
  },
  {
    text: "option",
    meaning: "選擇；選擇權",
    example: "We have the option of delivering the order on Tuesday or Thursday.",
    category: "製造業",
    importance: 3
  },
  {
    text: "output",
    meaning: "出產；生產；產量",
    example: "The changes have increased output by over ten percent.",
    category: "製造業",
    importance: 3
  },
  {
    text: "outsource",
    meaning: "外包",
    example: "The company's winning formula is to outsource all of its production.",
    category: "製造業",
    importance: 3
  },
  {
    text: "overproduction",
    meaning: "生產過剩",
    example: "Overproduction lowers prices and costs the company money.",
    category: "製造業",
    importance: 3
  },
  {
    text: "packaging",
    meaning: "包裝（業）；包裝材料",
    example: "By reducing packaging, we can save money and please customers.",
    category: "製造業",
    importance: 3
  },
  {
    text: "patent",
    meaning: "專利；專利權",
    example: "Their patent will expire next year and we can begin manufacturing the product.",
    category: "製造業",
    importance: 3
  },
  {
    text: "plant",
    meaning: "工廠",
    example: "The goal is to build two new plants in Mexico by the end of next year.",
    category: "製造業",
    importance: 3
  },
  {
    text: "power failure",
    meaning: "停電",
    example: "A power failure forced most factories in the region to halt operations.",
    category: "製造業",
    importance: 3
  },
  {
    text: "priority",
    meaning: "優先事項；優先權",
    example: "Safety is our priority here, so you must first learn how to work on the line.",
    category: "製造業",
    importance: 3
  },
  {
    text: "procedure",
    meaning: "程序；步驟",
    example: "Change in working procedures must be approved by the factory director.",
    category: "製造業",
    importance: 3
  },
  {
    text: "product line",
    meaning: "生產線；產品系列",
    example: "Our oldest product line is still our most popular.",
    category: "製造業",
    importance: 3
  },
  {
    text: "production",
    meaning: "生產；產量；產物",
    example: "Production increased by four percent when the work shifts were shortened.",
    category: "製造業",
    importance: 3
  },
  {
    text: "production capacity",
    meaning: "產能",
    example: "We have a production capacity of 500 units per hour.",
    category: "製造業",
    importance: 3
  },
  {
    text: "quality control",
    meaning: "品質管理（簡稱品管）",
    example: "Quality control must take place at every step of production.",
    category: "製造業",
    importance: 3
  },
  {
    text: "quality standard",
    meaning: "品質標準",
    example: "This year, Metro Factory experienced a noticeable decline in quality standards.",
    category: "製造業",
    importance: 3
  },
  {
    text: "randomly",
    meaning: "隨機地；任意地",
    example: "We randomly chose five products to inspect.",
    category: "製造業",
    importance: 3
  },
  {
    text: "raw material",
    meaning: "原料",
    example: "Finding cheap raw material helps keep our prices low.",
    category: "製造業",
    importance: 3
  },
  {
    text: "recall",
    meaning: "回收；召回",
    example: "The car company recalled 3,000 SUVs because of a brake problem.",
    category: "製造業",
    importance: 3
  },
  {
    text: "recycling",
    meaning: "回收；再生",
    example: "The authorities are considering implementing a mandatory electronics recycling program.",
    category: "製造業",
    importance: 3
  },
  {
    text: "representative",
    meaning: "代表；代理人",
    example: "Representatives from across the country attended the conference.",
    category: "製造業",
    importance: 3
  },
  {
    text: "responsibility",
    meaning: "責任；職責",
    example: "It is your responsibility to make sure that the quality is excellent.",
    category: "製造業",
    importance: 3
  },
  {
    text: "rival",
    meaning: "競爭者；對手",
    example: "Our biggest rival has released a new and cheaper product line.",
    category: "製造業",
    importance: 3
  },
  {
    text: "scrutiny",
    meaning: "仔細檢查；密切觀察（不可數）",
    example: "Even under the closest scrutiny, the product was found to be of the highest quality.",
    category: "製造業",
    importance: 3
  },
  {
    text: "semiconductor",
    meaning: "半導體",
    example: "Intel has its company's largest semiconductor plant outside the U.S. near Dublin.",
    category: "製造業",
    importance: 3
  },
  {
    text: "shortage",
    meaning: "短缺",
    example: "The biggest problem we're facing is a shortage of skilled workers.",
    category: "製造業",
    importance: 3
  },
  {
    text: "shut down",
    meaning: "停工；關閉（機器、公司等）",
    example: "The plant will be shut down while the assembly line is upgraded.",
    category: "製造業",
    importance: 3
  },
  {
    text: "sort",
    meaning: "挑選；把～分類",
    example: "The operators are sorting units that were rejected by our customers.",
    category: "製造業",
    importance: 3
  },
  {
    text: "strike",
    meaning: "罷工",
    example: "The labor unions called for a general strike.",
    category: "製造業",
    importance: 3
  },
  {
    text: "subcontract",
    meaning: "分包；轉包",
    example: "The work was subcontracted to a local construction company.",
    category: "製造業",
    importance: 3
  },
  {
    text: "substance",
    meaning: "物質；原料",
    example: "All dangerous substances are kept in a safe location.",
    category: "製造業",
    importance: 3
  },
  {
    text: "sufficiently",
    meaning: "足夠地",
    example: "The defects resulted from the workers not being sufficiently trained.",
    category: "製造業",
    importance: 3
  },
  {
    text: "supervisor",
    meaning: "監督者；管理人",
    example: "The supervisor makes sure that the workers are doing a good job.",
    category: "製造業",
    importance: 3
  },
  {
    text: "surplus",
    meaning: "過剩；剩餘物；盈餘",
    example: "Our policy is to keep a small surplus of items in stock.",
    category: "製造業",
    importance: 3
  },
  {
    text: "systematically",
    meaning: "有系統地；有條理地",
    example: "Doing things systematically helps make sure that everything gets done, and gets done well.",
    category: "製造業",
    importance: 3
  },
  {
    text: "uniformly",
    meaning: "一樣地；一致地",
    example: "If everything is done uniformly, then all the finished items should look exactly the same.",
    category: "製造業",
    importance: 3
  },
  {
    text: "warehouse",
    meaning: "倉庫",
    example: "Large items are kept in the warehouse until they are shipped.",
    category: "製造業",
    importance: 3
  },
  {
    text: "waste",
    meaning: "浪費；廢料；廢棄物",
    example: "We throw away items with even the smallest flaws, which I think is a real waste.",
    category: "製造業",
    importance: 3
  },
  {
    text: "wholesale",
    meaning: "批發（的）；躉售",
    example: "The wholesale price is twenty-five percent lower than the retail price.",
    category: "製造業",
    importance: 3
  },
  {
    text: "widget",
    meaning: "小機械",
    example: "We manufacture various widgets for digital cameras and cell phones.",
    category: "製造業",
    importance: 3
  },
  {
    text: "accept",
    meaning: "接受；認付（票據）；承兌；承認",
    example: "Do you accept American dollars?",
   category: "金融",
    importance: 3
  },
  {
    text: "account",
    meaning: "帳戶；帳目；說明",
    example: "Rick opened a new bank account on Monday.",
   category: "金融",
    importance: 3
  },
  {
    text: "account for",
    meaning: "（在數量上等）佔；解釋；導致",
    example: "The monthly bills I have to pay account for about forty percent of what I make each month.",
   category: "金融",
    importance: 3
  },
  {
    text: "accounting",
    meaning: "會計（學）；結帳",
    example: "The accounting department provides a company's financial information.",
   category: "金融",
    importance: 3
  },
  {
    text: "accumulate",
    meaning: "堆積；累積",
    example: "She accumulated over a million dollars through investing.",
   category: "金融",
    importance: 3
  },
  {
    text: "activate",
    meaning: "啟動；使活動",
    example: "After you have filled in the paperwork, we'll be able to activate your account.",
   category: "金融",
    importance: 3
  },
  {
    text: "aggressively",
    meaning: "強力地；有衝勁地",
    example: "I made a lot of money by investing aggressively in stocks.",
   category: "金融",
    importance: 3
  },
  {
    text: "allowance",
    meaning: "特別經費；零用錢；限額",
    example: "We have no budget allowance for company outings this year.",
   category: "金融",
    importance: 3
  },
  {
    text: "asset",
    meaning: "資產；財產；資源；優勢",
    example: "The company has many assets that it could sell to raise money.",
   category: "金融",
    importance: 3
  },
  {
    text: "ATM",
    meaning: "自動櫃員機",
    example: "This bank has ATMs in every large city and airport in America.",
   category: "金融",
    importance: 3
  },
  {
    text: "audit",
    meaning: "查帳；審計",
    example: "We have finished auditing the company's accounts, and everything seems to be correct.",
   category: "金融",
    importance: 3
  },
  {
    text: "balance",
    meaning: "結餘；未付款項",
    example: "The balance of your account is $78,000.",
   category: "金融",
    importance: 3
  },
  {
    text: "bank statement",
    meaning: "銀行對帳單",
    example: "I receive my bank statement every month.",
   category: "金融",
    importance: 3
  },
  {
    text: "bankbook",
    meaning: "銀行存摺",
    example: "You must present your bankbook if you wish to withdraw money from your account.",
   category: "金融",
    importance: 3
  },
  {
    text: "bond",
    meaning: "債券；公債；契約",
    example: "Savings bonds offer a low-risk return for your investment, but are not as profitable as a good stock.",
   category: "金融",
    importance: 3
  },
  {
    text: "borrow",
    meaning: "借入",
    example: "You can borrow up to one hundred thousand dollars and pay it back over five years.",
   category: "金融",
    importance: 3
  },
  {
    text: "bounce",
    meaning: "跳（票）",
    example: "Oh, no! My check to City Supermarket bounced!",
   category: "金融",
    importance: 3
  },
  {
    text: "budget",
    meaning: "編列預算；預算",
    example: "It is important to budget for the year so that we will have enough money.",
   category: "金融",
    importance: 3
  },
  {
    text: "bullish",
    meaning: "（股市行情）看漲的",
    example: "The market has been bullish for several months in a row.",
   category: "金融",
    importance: 3
  },
  {
    text: "calculate",
    meaning: "計算；估計",
    example: "Can you calculate how much the decorations will cost?",
   category: "金融",
    importance: 3
  },
  {
    text: "capital",
    meaning: "資金；資本；資方",
    example: "Without capital, you won't be able to get your business started.",
   category: "金融",
    importance: 3
  },
  {
    text: "cash flow",
    meaning: "現金流量",
    example: "The company has some cash flow problems.",
   category: "金融",
    importance: 3
  },
  {
    text: "cashier",
    meaning: "出納員",
    example: "Ms. Lee works at a supermarket as a cashier.",
   category: "金融",
    importance: 3
  },
  {
    text: "cautiously",
    meaning: "小心地；謹慎地",
    example: "You should invest more cautiously, or you could lose a lot of money.",
   category: "金融",
    importance: 3
  },
  {
    text: "certificate of deposit",
    meaning: "定期存款單",
    example: "A certificate of deposit has a higher interest rate than a savings account.",
   category: "金融",
    importance: 3
  },
  {
    text: "check",
    meaning: "支票",
    example: "I don't have cash. Can I write you a check?",
   category: "金融",
    importance: 3
  },
  {
    text: "checking account",
    meaning: "支票存款帳戶",
    example: "I need to make a withdrawal from my checking account.",
   category: "金融",
    importance: 3
  },
  {
    text: "client",
    meaning: "客戶；委託人",
    example: "Most of our clients are happy to pay for our services because we help them save money.",
   category: "金融",
    importance: 3
  },
  {
    text: "collateral",
    meaning: "抵押品；擔保品",
    example: "Without collateral, Mr. Thomas wasn't able to get a loan.",
   category: "金融",
    importance: 3
  },
  {
    text: "commission",
    meaning: "佣金；委任；委員會",
    example: "One of the advantages of investing online is that you don't need to pay commission to a broker.",
   category: "金融",
    importance: 3
  },
  {
    text: "commit",
    meaning: "把（錢）用於～",
    example: "With this kind of investment, you must commit your money for at least five years.",
   category: "金融",
    importance: 3
  },
  {
    text: "conservative",
    meaning: "保守的；謹慎的",
    example: "I should make about ten thousand dollars, and that's a conservative estimate.",
   category: "金融",
    importance: 3
  },
  {
    text: "convert",
    meaning: "轉變；兌換",
    example: "Please convert one hundred U.S. dollars into euros.",
   category: "金融",
    importance: 3
  },
  {
    text: "credit card",
    meaning: "信用卡",
    example: "I need to report a stolen credit card.",
   category: "金融",
    importance: 3
  },
  {
    text: "credit rating",
    meaning: "信用評等",
    example: "Bob's poor repayment history has really hurt his credit rating.",
   category: "金融",
    importance: 3
  },
  {
    text: "currency",
    meaning: "貨幣",
    example: "Where can I change foreign currency?",
   category: "金融",
    importance: 3
  },
  {
    text: "debit card",
    meaning: "簽帳卡",
    example: "You can use this debit card almost anywhere in the world.",
   category: "金融",
    importance: 3
  },
  {
    text: "debt",
    meaning: "債；欠款",
    example: "I have paid off all my debts; I don't owe money to anybody.",
   category: "金融",
    importance: 3
  },
  {
    text: "deduct",
    meaning: "扣除",
    example: "We can deduct the late fee if you pay the bill by the 9th.",
   category: "金融",
    importance: 3
  },
  {
    text: "deposit",
    meaning: "保證金；存款",
    example: "If you want to rent the apartment, you have to pay a two-month deposit.",
   category: "金融",
    importance: 3
  },
  {
    text: "depression",
    meaning: "蕭條；不景氣",
    example: "The stock market crash meant the coming of a depression.",
   category: "金融",
    importance: 3
  },
  {
    text: "desire",
    meaning: "意願；慾望",
    example: "I have no desire to invest my money; I'd rather keep it in the bank.",
   category: "金融",
    importance: 3
  },
  {
    text: "detail",
    meaning: "細目；細節",
    example: "Check the details on the bill to make sure that everything is correct.",
   category: "金融",
    importance: 3
  },
  {
    text: "dividend",
    meaning: "股息；紅利",
    example: "Are the dividends for this investment paid two or four times a year?",
   category: "金融",
    importance: 3
  },
  {
    text: "donation",
    meaning: "捐獻；捐贈",
    example: "With the economic recession, donations from companies and individuals are down.",
   category: "金融",
    importance: 3
  },
  {
    text: "down payment",
    meaning: "（分期付款）的頭期款",
    example: "We are saving money to make a down payment on the house we want to buy.",
   category: "金融",
    importance: 3
  },
  {
    text: "endorse",
    meaning: "背書；贊同",
    example: "Can you endorse the check, please?",
   category: "金融",
    importance: 3
  },
  {
    text: "exceed",
    meaning: "超出；勝過",
    example: "Luckily, Q1 profit exceeded the forecast.",
   category: "金融",
    importance: 3
  },
  {
    text: "exchange",
    meaning: "交換；兌換",
    example: "Please help me exchange these N.T. dollars for yuan.",
   category: "金融",
    importance: 3
  },
  {
    text: "expenditure",
    meaning: "消費；支出",
    example: "Company expenditures must be kept under strict control.",
   category: "金融",
    importance: 3
  },
  {
    text: "file",
    meaning: "提出（申請）；提起（訴訟）",
    example: "Have you filed your taxes for last year?",
   category: "金融",
    importance: 3
  },
  {
    text: "fill out",
    meaning: "填寫（表格）",
    example: "Please fill out the tax form using a black pen.",
   category: "金融",
    importance: 3
  },
  {
    text: "financial statement",
    meaning: "財務報表",
    example: "Workers should be able to read financial statements.",
   category: "金融",
    importance: 3
  },
  {
    text: "fiscal year",
    meaning: "會計年度",
    example: "My department needs to cut twenty percent of its budget by the end of the fiscal year.",
   category: "金融",
    importance: 3
  },
  {
    text: "forecast",
    meaning: "預測；預報",
    example: "According to our forecast, the company should be making a profit by next January.",
   category: "金融",
    importance: 3
  },
  {
    text: "fund",
    meaning: "基金；專款；資金",
    example: "I have most of my money invested in a special fund.",
   category: "金融",
    importance: 3
  },
  {
    text: "gross margin",
    meaning: "毛利",
    example: "Our company hopes to increase this year's gross margin by five percent.",
   category: "金融",
    importance: 3
  },
  {
    text: "in the red",
    meaning: "負債",
    example: "I wouldn't invest in this company if I were you. They've been in the red for the past seven years.",
   category: "金融",
    importance: 3
  },
  {
    text: "income statement",
    meaning: "損益表",
    example: "Income statements show how much money a company made and spent over a period of time.",
   category: "金融",
    importance: 3
  },
  {
    text: "installment",
    meaning: "分期付款",
    example: "Penny will pay off her student loans in sixty installments.",
   category: "金融",
    importance: 3
  },
  {
    text: "interest",
    meaning: "利息",
    example: "Interest rates are not expected to increase.",
   category: "金融",
    importance: 3
  },
  {
    text: "invest",
    meaning: "投資",
    example: "You should only invest as much money as you can afford to lose.",
   category: "金融",
    importance: 3
  },
  {
    text: "keep a record",
    meaning: "記錄；記下事情",
    example: "Tell Ms. Hopkins to keep a record of her expenses.",
   category: "金融",
    importance: 3
  },
  {
    text: "loan",
    meaning: "貸款",
    example: "The loan application is incomplete.",
   category: "金融",
    importance: 3
  },
  {
    text: "long-term",
    meaning: "長期的",
    example: "This is a long-term investment, so make sure you won't need the money within the next ten years.",
   category: "金融",
    importance: 3
  },
  {
    text: "mature",
    meaning: "（定存、票據等）到期",
    example: "When does my CD mature?",
   category: "金融",
    importance: 3
  },
  {
    text: "minimum",
    meaning: "最低限度（的）；最小數（的）",
    example: "Employees must work for a minimum of one year to be eligible for health benefits.",
   category: "金融",
    importance: 3
  },
  {
    text: "net income",
    meaning: "淨損益；淨收入",
    example: "B&G Co.'s net income last quarter was below expectations.",
   category: "金融",
    importance: 3
  },
  {
    text: "occur",
    meaning: "發生；出現；存在",
    example: "It may occur to you that your department needs a larger budget.",
   category: "金融",
    importance: 3
  },
  {
    text: "outstanding",
    meaning: "未償付的；未解決的；未做的",
    example: "We still have two bills outstanding, but I can pay them this week.",
   category: "金融",
    importance: 3
  },
  {
    text: "overall",
    meaning: "總共；全部；大體上",
    example: "You owe eleven thousand dollars overall.",
   category: "金融",
    importance: 3
  },
  {
    text: "overdraw",
    meaning: "透支",
    example: "I overdrew my account by five thousand dollars.",
   category: "金融",
    importance: 3
  },
  {
    text: "owe",
    meaning: "欠債",
    example: "You currently owe two thousand dollars.",
   category: "金融",
    importance: 3
  },
  {
    text: "penalty",
    meaning: "處罰；刑罰；罰款",
    example: "There will be a five percent penalty for any bills paid more than thirty days late.",
   category: "金融",
    importance: 3
  },
  {
    text: "PIN",
    meaning: "密碼；個人身分辨識碼",
    example: "You can change your PIN at the ATM.",
   category: "金融",
    importance: 3
  },
  {
    text: "portfolio",
    meaning: "投資組合；全部有價證券",
    example: "I only have four investments in my portfolio.",
   category: "金融",
    importance: 3
  },
  {
    text: "profit",
    meaning: "利益；有益於",
    example: "If we don't make a profit by the end of the year, we'll be out of business.",
   category: "金融",
    importance: 3
  },
  {
    text: "project",
    meaning: "評估；預估",
    example: "Our income is projected to rise by eight percent over the year.",
   category: "金融",
    importance: 3
  },
  {
    text: "pull out",
    meaning: "（從某活動）收手；收回",
    example: "If the investment keeps doing badly, I will have to pull my money out.",
   category: "金融",
    importance: 3
  },
  {
    text: "quota",
    meaning: "額度；目標；配額",
    example: "Salespeople that do not reach their quota will lose ten percent of their commission.",
   category: "金融",
    importance: 3
  },
  {
    text: "quote",
    meaning: "報價；引語；引文",
    example: "Can you give me a quote for remodeling the whole office?",
   category: "金融",
    importance: 3
  },
  {
    text: "realistic",
    meaning: "現實的；實際的",
    example: "If you think that investing can make you rich quickly, you are not being realistic.",
   category: "金融",
    importance: 3
  },
  {
    text: "recession",
    meaning: "經濟衰退",
    example: "The recession led to high unemployment across the United States.",
   category: "金融",
    importance: 3
  },
  {
    text: "reconcile",
    meaning: "調和；使一致",
    example: "The auditor tried to reconcile his expenses with his stated income.",
   category: "金融",
    importance: 3
  },
  {
    text: "refinance",
    meaning: "重新貸款",
    example: "When deciding whether or not to refinance, there are many factors to consider.",
   category: "金融",
    importance: 3
  },
  {
    text: "reimburse",
    meaning: "償還；賠償",
    example: "I will reimburse you the cost.",
   category: "金融",
    importance: 3
  },
  {
    text: "remittance",
    meaning: "匯款",
    example: "Some companies accept bank remittances as payment for products.",
   category: "金融",
    importance: 3
  },
  {
    text: "require",
    meaning: "需要；要求",
    example: "Most banks require some kind of ID before they will let you open an account.",
   category: "金融",
    importance: 3
  },
  {
    text: "restricted",
    meaning: "限制的；管制的",
    example: "This special account is restricted to local customers.",
   category: "金融",
    importance: 3
  },
  {
    text: "return",
    meaning: "收益；利潤；利息",
    example: "I got a really good return on my investment.",
   category: "金融",
    importance: 3
  },
  {
    text: "revenue",
    meaning: "收益；稅收",
    example: "The company's revenues fell last year.",
   category: "金融",
    importance: 3
  },
  {
    text: "safe-deposit box",
    meaning: "（銀行）保險箱",
    example: "She kept her jewels in her safe-deposit box.",
   category: "金融",
    importance: 3
  },
  {
    text: "savings account",
    meaning: "儲蓄存款帳戶",
    example: "I need to transfer money from my savings account to my checking account.",
   category: "金融",
    importance: 3
  },
  {
    text: "spouse",
    meaning: "配偶",
    example: "Both you and your spouse have to sign the loan agreement.",
   category: "金融",
    importance: 3
  },
  {
    text: "subsidy",
    meaning: "補助；津貼",
    example: "Japan and the United States will be discussing subsidies to the auto industry.",
   category: "金融",
    importance: 3
  },
  {
    text: "target",
    meaning: "目標",
    example: "My target is to make a million dollars over thirty years.",
   category: "金融",
    importance: 3
  },
  {
    text: "tax refund",
    meaning: "退稅",
    example: "I got a really big tax refund last year.",
   category: "金融",
    importance: 3
  },
  {
    text: "teller",
    meaning: "（銀行）出納員",
    example: "Marcy started as a bank teller, but now she's a loan officer.",
   category: "金融",
    importance: 3
  },
  {
    text: "transaction",
    meaning: "辦理商務往來；交易",
    example: "I'd like a list of my last ten transactions.",
   category: "金融",
    importance: 3
  },
  {
    text: "transfer",
    meaning: "轉帳",
    example: "The money has been transferred into my account.",
   category: "金融",
    importance: 3
  },
  {
    text: "traveler's check",
    meaning: "旅行支票",
    example: "In what denominations would you like the traveler's checks?",
   category: "金融",
    importance: 3
  },
  {
    text: "typically",
    meaning: "總是；向來；典型地",
    example: "It typically takes two days for the money to reach your account.",
   category: "金融",
    importance: 3
  },
  {
    text: "voucher",
    meaning: "證明文件；收據；保證人",
    example: "The voucher is valid until April 30th.",
   category: "金融",
    importance: 3
  },
  {
    text: "wire",
    meaning: "匯款",
    example: "Judy's father wired money to her bank account.",
   category: "金融",
    importance: 3
  },
  {
    text: "withdraw",
    meaning: "提款",
    example: "I withdrew $300 from my savings account.",
   category: "金融",
    importance: 3
  },
  {
    text: "withhold",
    meaning: "從收入中扣除；保留；抑制；阻擋",
    example: "About two hundred dollars is withheld from Anna's paycheck each month.",
   category: "金融",
    importance: 3
  },
  {
    text: "yield",
    meaning: "產生（效果、收益等）",
    example: "The investment yielded a profit of two thousand dollars.",
   category: "金融",
    importance: 3
  },
  {
    text: "acquisition",
    meaning: "收購（公司等）；獲得（物）",
    example: "My company is looking into the acquisition of a small publishing firm.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "adjacent",
    meaning: "緊接著的；比鄰的",
    example: "The research department is adjacent to the design department.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "affiliated company",
    meaning: "關係企業",
    example: "One of our affiliated companies is located in Hong Kong.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "ahead of the game",
    meaning: "在（某領域）領先",
    example: "Toyota is ahead of the game in creating an electric vehicle, compared to American automakers.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "allocate",
    meaning: "分派；分配",
    example: "The new CFO allocated a million dollars for product design.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "alternative energy",
    meaning: "替代能源",
    example: "Scientists are researching alternative energy sources for cars.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "arena",
    meaning: "競爭場所；競技場",
    example: "The telecommunication arena is filled with competitors.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "bankruptcy",
    meaning: "破產",
    example: "After losing money for two years, the company declared bankruptcy.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "basic testing",
    meaning: "基本測試",
    example: "We did all the basic testing during development.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "boast",
    meaning: "以～而自豪",
    example: "The company has won most of the awards; they have a lot to boast about.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "branch office",
    meaning: "分公司",
    example: "Our boss has approved the opening of a branch office in Beijing.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "branch out",
    meaning: "擴充（業務）",
    example: "The bank has now branched out into selling insurance.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "breakthrough",
    meaning: "突破",
    example: "Researchers predict a major breakthrough within four months.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "brochure",
    meaning: "小冊子；指南",
    example: "Our goal is to have our brochures in every hotel lobby in the country.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "cold call",
    meaning: "陌生電訪；主動以電話推銷商品",
    example: "As part of her job, Betty has to make cold calls to potential clients.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "company profile",
    meaning: "公司概況",
    example: "The company profile includes an overview, a financial profile, and financial outlook.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "competent",
    meaning: "有能力的；能勝任的",
    example: "The R&D department is full of competent engineers.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "comprehensive",
    meaning: "廣泛的；包羅萬象的",
    example: "Before making any important decision, be sure to get a comprehensive report.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "conglomerate",
    meaning: "企業集團",
    example: "Four South Korean conglomerates account for much of the growth in the economy.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "contribution",
    meaning: "貢獻；捐款；捐贈物",
    example: "He doesn't make much of a contribution to his team.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "core business",
    meaning: "核心事業",
    example: "We must focus on our core business.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "corner the market",
    meaning: "壟斷市場",
    example: "Our goal is to corner the market nationwide.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "corporation",
    meaning: "公司；企業",
    example: "The company has started to cooperate with world famous corporations.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "counselor",
    meaning: "顧問",
    example: "We can ask our counselors for advice about the Hansen Project.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "cutting-edge",
    meaning: "尖端的；先進的",
    example: "Cutting-edge technology increases efficiency, but it also increases costs.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "delegate",
    meaning: "委派（某人）做；授（權）",
    example: "A good leader delegates work and doesn't try to do everything himself.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "demographic",
    meaning: "（按性別、年齡、收入等區分的）人口統計資料；以市場作區隔的族群",
    example: "With a slight change in the product, we can add a new demographic.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "depreciation",
    meaning: "折舊",
    example: "Depreciation of machinery cost the company a lot of money last year.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "division",
    meaning: "事業部；部門",
    example: "It's likely that we'll add a new division this year.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "dominate",
    meaning: "支配；在～中占主要地位",
    example: "Our company hopes to dominate the cell phone industry in five years.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "enhancement",
    meaning: "（品質、清晰度等的）提高、提升",
    example: "The design department is working on product quality enhancement.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "ergo-designed",
    meaning: "人體工學設計的",
    example: "Our goal is to make an ergo-designed chair to aid in comfort.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "expand",
    meaning: "張開；擴張",
    example: "Our company is looking to expand this year.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "expertise",
    meaning: "專門知識；專門技術",
    example: "The sales department lacks expertise in layout and design.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "feature",
    meaning: "（產品）特色",
    example: "The touch screen is one of the most popular features on this model.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "found",
    meaning: "創立",
    example: "Microsoft was founded in 1975 by Bill Gates and Paul Allen.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "functionality",
    meaning: "功能",
    example: "The new software comes with additional functionality.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "hands-on",
    meaning: "實際動手做的；親身投入的",
    example: "A manager who believes in the hands-on approach will work closely with his crew.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "high-end",
    meaning: "高消費階層的；迎合高層次消費者的",
    example: "The market for high-end cars has grown by thirty percent in the last ten years.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "hostile takeover",
    meaning: "惡意併購",
    example: "News of the hostile takeover shocked the industry.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "in association with",
    meaning: "與～合作",
    example: "The company is developing a new line of fall fashions in association with this designer.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "incorporate",
    meaning: "納入；併入；合併",
    example: "Progress Group will incorporate safety considerations into its factory design.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "initiate",
    meaning: "發起；創始",
    example: "R&D will initiate the new project next month.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "innovation",
    meaning: "創新",
    example: "The company encourages innovation.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "instrumental",
    meaning: "有幫助的；起作用的",
    example: "The mergers were instrumental in expanding the company.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "integrated",
    meaning: "整合的",
    example: "The integrated system will make things more efficient.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "intellectual property",
    meaning: "智慧財產權",
    example: "You should apply for a patent for your new design to protect your intellectual property.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "joint venture",
    meaning: "合資企業",
    example: "The joint venture will be established by the end of next year.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "jurisdiction",
    meaning: "管轄範圍",
    example: "All IT and computer-related issues fall under the jurisdiction of the MIS department.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "keep up with",
    meaning: "趕上；保持聯繫；持續學習（新事物）",
    example: "Although I graduated over ten years ago, I have always kept up with the latest research.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "kudos",
    meaning: "名譽；光榮；稱讚；讚賞",
    example: "The company has won kudos for its great new technology.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "last but not least",
    meaning: "最後，但也同樣重要的是～",
    example: "Last but not least, Judy will tell us all about the cost of our proposal.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "listed company",
    meaning: "上市公司",
    example: "The chip manufacturer is a listed company on the NASDAQ.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "market capitalization",
    meaning: "市價總值",
    example: "The company's market capitalization is nearly $2 billion.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "market segmentation",
    meaning: "市場區隔",
    example: "Market segmentation allowed us to target our ads more effectively.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "marketable",
    meaning: "有銷路的；暢銷的；市場的",
    example: "It was a great product, but the high price meant it wasn't marketable.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "match sth./sb. Up",
    meaning: "撮合；媒合",
    example: "Can you match us up with a similar company in India?",
    category: "企業發展",
    importance: 3
  },
  {
    text: "merger",
    meaning: "合併",
    example: "Most employees are not happy about the merger of the two companies.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "monopoly",
    meaning: "獨占；專賣；壟斷",
    example: "IBM had a monopoly on home computers during much of the decade.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "ODM",
    meaning: "原始設計製造商；原廠委託設計",
    example: "Our company works with an ODM in Mexico and two in Brazil.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "OEM",
    meaning: "原始設備製造商；原廠委託製造",
    example: "A key part of our success was finding OEMs with the lowest prices.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "operation",
    meaning: "營運；經營",
    example: "Our company has been in operation since 1996.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "original",
    meaning: "獨創性的；原創性的",
    example: "The sound quality and prices differentiate pirated CDs from original CDs.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "outlook",
    meaning: "展望；看法；景色",
    example: "With the appointment of a new CEO, the company's outlook has gotten better.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "oversee",
    meaning: "看管；監督",
    example: "There are too many projects for one manager to oversee.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "pamphlet",
    meaning: "小冊子",
    example: "Several new customers found out about our company through our pamphlets.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "parent company",
    meaning: "母公司",
    example: "Our parent company's head office is located in Houston.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "preliminary stage",
    meaning: "初步階段",
    example: "Production went through three preliminary stages before the final product was ready.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "product development",
    meaning: "產品開發；產品研發",
    example: "Although product development is important, I think we also need to find ways of upgrading our distribution network.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "prototype",
    meaning: "原型；標準；模範",
    example: "A prototype will be ready for testing in two years.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "research and development",
    meaning: "研發",
    example: "Research and development is an important part of our company's future.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "resistant",
    meaning: "抗～的；防～的",
    example: "This new camera is water resistant up to 100 meters deep.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "resource",
    meaning: "資源；物力",
    example: "Our employees are our number one resource.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "simulation test",
    meaning: "模擬測試",
    example: "I think we'll need to design some new simulation tests.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "slogan",
    meaning: "標誌；宣傳口號",
    example: "The company's slogan hasn't changed in thirty years.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "specs",
    meaning: "（產品）規格",
    example: "All the specs and technical details are on the last page of the manual.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "state-of-the-art",
    meaning: "最新型的；最優良的",
    example: "The engineer is helping to design a state-of-the-art smartphone.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "state-run enterprise",
    meaning: "國營企業",
    example: "State-run enterprises are often criticized as being inefficient.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "stylish",
    meaning: "時髦的；有風格的",
    example: "I like the car's stylish new design.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "subsidiary",
    meaning: "子公司",
    example: "The clothing business was transferred to a subsidiary.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "task",
    meaning: "任務；工作；作業",
    example: "The president gave me the task of hiring two new engineers.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "team up with",
    meaning: "與～合作",
    example: "R&D has teamed up with the designers to work on the problem.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "telemarketing",
    meaning: "電話行銷",
    example: "The telemarketing industry is growing in India.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "time frame",
    meaning: "時間範圍",
    example: "It became clear we couldn't finish the design within the current time frame.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "trial run",
    meaning: "試用",
    example: "The new system needs a trial run before it can be put into use.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "underestimate",
    meaning: "低估",
    example: "We underestimated the cost of shipping our product to Europe.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "unique",
    meaning: "獨一無二的；獨特的",
    example: "The sales campaign focused on our product's unique features.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "user-friendly",
    meaning: "容易使用的；（設計時）考慮使用者需要的",
    example: "The average consumer complained that the software was not user-friendly.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "workshop",
    meaning: "專題討論會；研討會",
    example: "The morning was spent in a workshop on dealing with customer complaints.",
    category: "企業發展",
    importance: 3
  },
  {
    text: "address book",
    meaning: "通訊錄",
    example: "Let me see if I have his number in my address book.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "administration",
    meaning: "行政；管理",
    example: "Pamela, could you give us an overview of the Administration Department?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "alphabetical",
    meaning: "按字母順序的",
    example: "The files are arranged in alphabetical order.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "appoint",
    meaning: "任命；指派",
    example: "He had the most successful track record, so he was appointed head of the new project.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "appreciation",
    meaning: "感激；欣賞；評價",
    example: "The company gave him a bonus in appreciation for all his hard work.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "assignment",
    meaning: "分派；任務",
    example: "It was difficult for me to take care of both John's assignment and my own responsibilities.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "association",
    meaning: "協會；聯合",
    example: "Our long-term association with your advertising firm has brought benefits to both sides.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "attachment",
    meaning: "附件；附加檔",
    example: "The attachments are the three files you asked for.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "auditorium",
    meaning: "會堂；禮堂；觀眾席",
    example: "There is a meeting this afternoon in the auditorium of our head office.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "authority",
    meaning: "權限",
    example: "I'm afraid I don't have the authority to approve that.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "badge",
    meaning: "名牌；識別證",
    example: "Employees should wear their badges at all times in the building.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "beforehand",
    meaning: "事先；預先",
    example: "If you need to take a day off, be sure to tell the manager beforehand.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "board meeting",
    meaning: "董事會議",
    example: "No major decisions were made at last month's board meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "board of directors",
    meaning: "董事會",
    example: "The board of directors met to discuss the future of the company.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "bottom line",
    meaning: "基本要求或情況；結果",
    example: "The bottom line is we've got to get this thing done by the end of the week.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "briefing",
    meaning: "簡報",
    example: "The CEO gave a quick briefing to all the department managers.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "bring in",
    meaning: "賺進（利潤）；招徠（顧客）",
    example: "Answering the phone quickly helps a business bring in more sales.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "bring up",
    meaning: "開始說；提起（話題）",
    example: "Does anybody want to bring up anything else before we close the meeting?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "bulk mail",
    meaning: "大宗郵件",
    example: "The brochures were sent out by bulk mail in order to save money.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "bulletin",
    meaning: "告示；快報",
    example: "Put your announcement on the bulletin board so others will see it.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "business casual",
    meaning: "輕鬆但不失儀態的上班穿著",
    example: "In the 1990s, business casual became a popular dress code in white-collar workplaces.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "business trip",
    meaning: "出差",
    example: "Mr. Brown is on a business trip this week.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "CC",
    meaning: "副本抄送",
    example: "Please CC me the e-mail.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "code",
    meaning: "章程；法規",
    example: "We don't have a dress code in the office, but it's better to wear something smart.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "colleague",
    meaning: "同事；同僚",
    example: "My colleague would be happy to meet with you and answer any questions you have.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "commitment",
    meaning: "責任；委託；承諾",
    example: "Ted has a very strong commitment to his work.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "committee",
    meaning: "委員會；全體委員",
    example: "The company set up a committee to look into ways to improve sales.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "compatible",
    meaning: "可共處的；（電腦）相容的",
    example: "Are these printers compatible with our computer system?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "characteristic",
    meaning: "特色；特徵（多用複數）",
    example: "Explain the characteristics of the product to the customer.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "consensus",
    meaning: "（意見）一致；共識",
    example: "The committee could not come to a consensus.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "controversy",
    meaning: "爭議",
    example: "The PR department did everything it could to keep the controversy from getting into the newspapers.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "correspondence",
    meaning: "通信；往返書信；一致；調和",
    example: "Most of the company's correspondence is now done by e-mail.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "courier",
    meaning: "快遞",
    example: "I am sending this package by courier right away, as it must arrive before noon.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "cubicle",
    meaning: "（辦公室）小隔間",
    example: "A big problem with cubicles is the lack of privacy.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "cursor",
    meaning: "游標",
    example: "Can you move the cursor to the first line for me?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "delete",
    meaning: "刪除；消掉",
    example: "Can I delete these e-mails now?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "discharge",
    meaning: "解雇；開除；卸（貨）",
    example: "He was discharged after failing to meet the company standards.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "display",
    meaning: "展示；陳列；呈現",
    example: "The office rules are displayed on the message board.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "document",
    meaning: "公文；文件",
    example: "Sue prepared an important document for the meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "drawer",
    meaning: "抽屜",
    example: "I keep all my important files in the bottom drawer.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "duplicate",
    meaning: "複製品；副本",
    example: "Give the client the original copy and keep the duplicate for our records.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "e-mail",
    meaning: "（寄）電子郵件",
    example: "I'll e-mail you her contact information.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "enlarge",
    meaning: "放大",
    example: "How do I enlarge copies from A4 to A3?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "executive",
    meaning: "經理主管級人員；執行的；行政的",
    example: "He is an executive in a multinational corporation.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "expose",
    meaning: "使接觸；使暴露；揭露",
    example: "The problem was exposed at the meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "express",
    meaning: "快速的；快遞的",
    example: "This letter needs to arrive tomorrow, so please send it by express delivery.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "extension",
    meaning: "分機號碼；分機電話",
    example: "I'm at extension 123.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "face down",
    meaning: "正面朝下",
    example: "Place the papers face down on the paper tray.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "facilitate",
    meaning: "使容易；使順暢",
    example: "An open office facilitates teamwork; one with many small offices and closed doors doesn't.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "figure out",
    meaning: "找出；解決；弄清楚",
    example: "I can't figure out how to use the fax machine.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "filing cabinet",
    meaning: "檔案櫃",
    example: "I lost my key to the filing cabinet.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "floor",
    meaning: "發言權",
    example: "You have the floor, George.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "fold",
    meaning: "摺",
    example: "We should hire someone to fold all these letters and put them in the envelopes.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "forward",
    meaning: "轉寄",
    example: "Please forward me his e-mail and I'll get back to you.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "give sb./sth. the green light",
    meaning: "允許某人（做某事）；准許某事進行",
    example: "She's still waiting for her boss to give her the green light.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "glimpse",
    meaning: "一瞥；瞥見",
    example: "I only had a glimpse of the fax; I'll read it properly now.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "go ahead",
    meaning: "開始（做某事）",
    example: "Peter, would you like to go ahead and start the meeting?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "ignore",
    meaning: "忽視；不理睬",
    example: "You must answer the telephone; you can't keep ignoring it.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "implement",
    meaning: "實施；執行",
    example: "We reassessed customer-service ratings two months after the method was implemented.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "in case",
    meaning: "以防；萬一",
    example: "In case I didn't mention it, I'll be arriving on Wednesday, January 10th.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "ink cartridge",
    meaning: "（印表機的）墨水匣",
    example: "The cost of a new ink cartridge was almost half the purchase price of the printer.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "interaction",
    meaning: "交互作用；互相影響",
    example: "Computers are more efficient, but customers often prefer interaction with real people.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "interrupt",
    meaning: "打斷；插嘴",
    example: "Sorry to interrupt. Shouldn't we get back on topic?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "junk mail",
    meaning: "垃圾郵件",
    example: "The IT department installed a filter to block junk mail.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "kit",
    meaning: "成套工具（或物件等）",
    example: "Each kit includes a company overview, notepad, and a pen.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "label",
    meaning: "（貼上）標籤",
    example: "The file was labelled \"Top Secret.\"",
    category: "辦公室",
    importance: 3
  },
  {
    text: "layout",
    meaning: "設計（圖）；格局；陳設",
    example: "I'm working on the layout of the company newsletter.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "letterhead",
    meaning: "信頭",
    example: "All correspondence with our clients must be put on a company letterhead.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "mailbox",
    meaning: "郵件信箱",
    example: "You can't receive e-mail because your mailbox is over its limit.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "manual",
    meaning: "手冊；簡介",
    example: "The DVD player isn't working. Do you know where the manual is?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "mention",
    meaning: "提到；說起",
    example: "I think what you said is important. Maybe you should mention it at the meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "minutes",
    meaning: "會議記錄",
    example: "No one on the staff enjoys taking the minutes.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "motion",
    meaning: "臨時動議",
    example: "I'd like to make a motion.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "nominate",
    meaning: "提名",
    example: "The board will nominate Paul for chairman.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "on duty",
    meaning: "當班",
    example: "Richard is on duty from two to ten.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "on the same page",
    meaning: "達成共識",
    example: "Mr. Allen called a meeting to make sure his team members were on the same page.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "out of",
    meaning: "用完（某物）",
    example: "We're out of printer ink. Can you order some more?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "paper clip",
    meaning: "迴紋針",
    example: "Use a paper clip to hold this file together.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "paper jam",
    meaning: "卡紙",
    example: "If you have a paper jam, make sure you clear the jammed paper properly.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "partition",
    meaning: "（辦公室的）隔板",
    example: "If we raise the partitions between cubicles by just two inches, it will be a lot quieter.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "photocopier",
    meaning: "影印機",
    example: "Our photocopier is broken again.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "physically",
    meaning: "身體上；物理上；按照自然規律地",
    example: "The good thing about e-mails is that you don't have to physically send them.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "pick (someone's) brain",
    meaning: "聽取意見或建議",
    example: "Can I pick your brain on this project I'm working on?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "popularity",
    meaning: "普及；大眾化；名望",
    example: "Faxes are losing popularity as people prefer to send e-mails.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "postage",
    meaning: "郵資",
    example: "How much is the postage for a postcard?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "postmark",
    meaning: "蓋郵戳",
    example: "The letter was postmarked Taipei.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "postpone",
    meaning: "延後",
    example: "An emergency has come up and I've got to postpone our meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "pound key",
    meaning: "（電話上的）井字鍵",
    example: "To hear this menu again, press the pound key.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "printed matter",
    meaning: "印刷品",
    example: "The rate for printed matter is cheaper.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "process",
    meaning: "過程；程序；方法",
    example: "All staff must follow the same process for booking time off work.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "projector",
    meaning: "投影機",
    example: "We need to prepare a microphone and a projector for the meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "pros and cons",
    meaning: "利弊得失",
    example: "We discussed the pros and cons of changing the company's operating system.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "provider",
    meaning: "供應者；供應商",
    example: "The Internet provider will send you monthly bills.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "punch in",
    meaning: "上班打卡",
    example: "Jason usually punches in around 8:50 a.m.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "put through",
    meaning: "轉接電話",
    example: "Amy, if my wife calls, please put her through.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "receiver",
    meaning: "電話筒",
    example: "On the third ring, I picked up the receiver in a hurry.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "reception",
    meaning: "收訊；接收（品質）",
    example: "I need to find an area with good reception to make a call.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "receptionist",
    meaning: "櫃檯人員；接待人員",
    example: "As Sam came in the door, the receptionist greeted him.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "recipient",
    meaning: "收件者",
    example: "Enter the recipient's e-mail address, choose the file you want to send, and click on the \"Send\" button.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "reduction",
    meaning: "減少；降低",
    example: "Recycling helped us achieve a big reduction in paper costs last year.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "refill",
    meaning: "再裝填",
    example: "Susan refilled the paper tray.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "reform",
    meaning: "改革；革新",
    example: "The company promised to reform policies on vacation time and sick leave.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "regarding",
    meaning: "關於；就～而論",
    example: "We'll be happy to answer any of your questions regarding these changes.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "registered letter",
    meaning: "掛號信",
    example: "It will cost you slightly more than the amount of first class postage to send a registered letter.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "relevant",
    meaning: "有關的",
    example: "Why are you talking about that project? It's not relevant to our discussion.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "rely",
    meaning: "依賴；仰賴",
    example: "You can rely on Judy to get everything done on time.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "replace",
    meaning: "取代；代替",
    example: "All the chairs have been replaced with newer, more comfortable ones.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "requisition form",
    meaning: "需求單",
    example: "You need to fill out the purchase requisition form and have it signed by your supervisor.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "reset",
    meaning: "重新設定",
    example: "To cancel, press the \"Reset\" button.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "resolution",
    meaning: "（會議等的）決議",
    example: "The resolution was passed by a two-thirds majority.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "return address",
    meaning: "寄件人地址",
    example: "Please make sure your return address is correct.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "revise",
    meaning: "修訂",
    example: "The office rules are being revised, so we'll have new ones very soon.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "salutation",
    meaning: "稱謂",
    example: "The next question is whether to use a colon, comma, or dash after the salutation.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "seminar",
    meaning: "研討會；專題討論會",
    example: "Here is the schedule for the seminar.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "shareholder",
    meaning: "股東",
    example: "All shareholders get equal votes at the annual general meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "sharp",
    meaning: "正好；（時間）整",
    example: "The meeting starts at nine o'clock sharp, so don't be late.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "shredder",
    meaning: "碎紙機",
    example: "Our shredder is broken, so I'll tear these confidential documents up manually.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "smudge",
    meaning: "髒污",
    example: "A copier that has been used a lot often has some dark smudges.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "staple",
    meaning: "用釘書機裝釘",
    example: "Could you please staple the reports together?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "stationery",
    meaning: "文具；信紙（皆不可數）",
    example: "I need some more stationery: just some paper and pens.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "stay on top of",
    meaning: "獲知最新消息；完全掌握",
    example: "Regular meetings help a business stay on top of any problems.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "stock",
    meaning: "存貨；庫存；存量",
    example: "If you need any stock for your department, just ask your supervisor.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "stockroom",
    meaning: "儲藏室",
    example: "You can walk to the stockroom to see if there are any toner cartridges left.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "subject",
    meaning: "主旨",
    example: "Subject: Your order has been shipped.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "subordinate",
    meaning: "下屬",
    example: "Mr. Brown valued opinions from his subordinates.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "summarize",
    meaning: "摘要；扼要說明",
    example: "The chairman quickly summarized his points at the board meeting.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "supply room",
    meaning: "（供應必需品的）補給房；儲藏室",
    example: "Only the secretary has access to the supply room.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "swipe card",
    meaning: "刷卡卡片",
    example: "What if I lose my swipe card?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "take effect",
    meaning: "實施；生效",
    example: "The new policies will take effect next month.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "take into consideration",
    meaning: "斟酌；加以考慮",
    example: "We promise to take your suggestion into consideration.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "take part",
    meaning: "參加；參與",
    example: "Will you be taking part in the running of the business?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "text message",
    meaning: "簡訊",
    example: "Do you often receive unwanted text messages on your cell phone?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "tie up loose ends",
    meaning: "處理枝節問題",
    example: "We can tie up loose ends on Friday.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "toll-free",
    meaning: "免付費（的）",
    example: "Please call our toll-free number, 0800-080-123.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "toner",
    meaning: "碳粉",
    example: "The copy machine will indicate when toner needs to be replaced.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "unanimous",
    meaning: "一致同意的；無異議的",
    example: "The board's vote to hire Ms. Dean as CEO was unanimous.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "under no circumstances",
    meaning: "無論如何都不～",
    example: "Under no circumstances are you to smoke in this office.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "verbally",
    meaning: "口頭上；言詞上",
    example: "Employees should be told in writing that they are being fired, but only after first being told verbally.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "version",
    meaning: "版本；（某一事物的）變化形式",
    example: "Which software version is your computer running?",
    category: "辦公室",
    importance: 3
  },
  {
    text: "voicemail",
    meaning: "語音信箱",
    example: "Calls to your number are automatically forwarded to voicemail if you don't answer within 30 seconds.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "warning",
    meaning: "警告；提醒",
    example: "If you keep breaking office rules, the manager will give you a written warning.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "when it comes to",
    meaning: "說到～；就～而論",
    example: "You need to talk to the building manager when it comes to an elevator problem.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "your call",
    meaning: "隨你便",
    example: "You can either stay or leave. It's your call.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "zip code",
    meaning: "郵遞區號",
    example: "The map clearly shows zip codes of Florida.",
    category: "辦公室",
    importance: 3
  },
  {
    text: "access card",
    meaning: "門禁卡",
    example: "All employees get an access card with their photo on it.",
    category: "人事",
    importance: 3
  },
  {
    text: "achievement",
    meaning: "完成；成就；成績",
    example: "He is a man of many achievements, both in the business world and in his personal life.",
    category: "人事",
    importance: 3
  },
  {
    text: "annual leave",
    meaning: "年假",
    example: "Annual leave is one week in the second year.",
    category: "人事",
    importance: 3
  },
  {
    text: "apply",
    meaning: "申請；適用；應用",
    example: "Why don't you apply for the job?",
    category: "人事",
    importance: 3
  },
  {
    text: "apprentice",
    meaning: "學徒；初學者",
    example: "Most skilled laborers learn their trade by becoming apprentices to more experienced people.",
    category: "人事",
    importance: 3
  },
  {
    text: "background",
    meaning: "經歷；背景；幕後",
    example: "Please tell me briefly about your educational background and job history.",
    category: "人事",
    importance: 3
  },
  {
    text: "basis",
    meaning: "基準；根據",
    example: "Your experience and qualifications are the basis for your starting salary.",
    category: "人事",
    importance: 3
  },
  {
    text: "be aware of",
    meaning: "知道；了解；注意到",
    example: "Are you aware of the extra hours that come with the position?",
    category: "人事",
    importance: 3
  },
  {
    text: "benefit",
    meaning: "好處；利益；福利",
    example: "The salary is not very good, but the benefits are great.",
    category: "人事",
    importance: 3
  },
  {
    text: "bread and butter",
    meaning: "生計；謀生之道",
    example: "Sales to schools are our company's bread and butter.",
    category: "人事",
    importance: 3
  },
  {
    text: "candidate",
    meaning: "申請人；應徵者；候選人",
    example: "Only the best candidates will be invited to an interview.",
    category: "人事",
    importance: 3
  },
  {
    text: "career",
    meaning: "職業；生涯",
    example: "Why did you choose this career?",
    category: "人事",
    importance: 3
  },
  {
    text: "challenge",
    meaning: "挑戰；艱鉅的事",
    example: "Lee's job was difficult, but he enjoyed the challenge.",
    category: "人事",
    importance: 3
  },
  {
    text: "commensurate",
    meaning: "相稱的；相當的",
    example: "You will receive a new salary commensurate with the position.",
    category: "人事",
    importance: 3
  },
  {
    text: "communication",
    meaning: "溝通；傳達",
    example: "This position requires strong communication skills.",
    category: "人事",
    importance: 3
  },
  {
    text: "compensate",
    meaning: "補償；給予報酬",
    example: "You will be compensated for any extra hours you work.",
    category: "人事",
    importance: 3
  },
  {
    text: "compliment",
    meaning: "讚美（的話）；恭維；祝賀",
    example: "Steve paid Jill a compliment for her excellent work.",
    category: "人事",
    importance: 3
  },
  {
    text: "conduct",
    meaning: "行為；舉止；指揮；管理",
    example: "She was given a promotion because of her excellent conduct at work.",
    category: "人事",
    importance: 3
  },
  {
    text: "confidence",
    meaning: "自信；信心",
    example: "I can see you certainly have enough confidence for the position, but do you have the experience?",
    category: "人事",
    importance: 3
  },
  {
    text: "constantly",
    meaning: "持續不斷地；經常",
    example: "She is constantly talking about her salary; she rarely talks about anything else!",
    category: "人事",
    importance: 3
  },
  {
    text: "constraint",
    meaning: "限制；約束",
    example: "As our department is facing serious financial constraints, we're unable to hire anyone else.",
    category: "人事",
    importance: 3
  },
  {
    text: "contract employee",
    meaning: "約聘人員",
    example: "Contract employees are beneficial, but they often show less loyalty to the companies they work for.",
    category: "人事",
    importance: 3
  },
  {
    text: "contribute",
    meaning: "貢獻；捐助；導致",
    example: "With my experience, I feel I can contribute a lot to the company's success.",
    category: "人事",
    importance: 3
  },
  {
    text: "cover letter",
    meaning: "求職信",
    example: "Keep your cover letter short, professional, and courteous.",
    category: "人事",
    importance: 3
  },
  {
    text: "dedication",
    meaning: "奉獻；致力",
    example: "Her dedication to the job has finally earned her a promotion.",
    category: "人事",
    importance: 3
  },
  {
    text: "eligible",
    meaning: "有資格的",
    example: "I'll be eligible for retirement next year.",
    category: "人事",
    importance: 3
  },
  {
    text: "employ",
    meaning: "雇用；受雇",
    example: "The company employs over a thousand people",
    category: "人事",
    importance: 3
  },
  {
    text: "enthusiastic",
    meaning: "熱情的；熱烈的",
    example: "Julia is enthusiastic about everything.",
    category: "人事",
    importance: 3
  },
  {
    text: "evaluate",
    meaning: "考核",
    example: "Employees are evaluated three times a year.",
    category: "人事",
    importance: 3
  },
  {
    text: "experience",
    meaning: "經驗；體驗；資歷",
    example: "Pat worked in a hotel during the summer to get some work experience.",
    category: "人事",
    importance: 3
  },
  {
    text: "expert",
    meaning: "專家",
    example: "You were chosen for the job because you are an expert on doing business in China.",
    category: "人事",
    importance: 3
  },
  {
    text: "fill-in",
    meaning: "職務代理人",
    example: "If you want to take a day off, you'll have to find someone to be your fill-in.",
    category: "人事",
    importance: 3
  },
  {
    text: "follow up",
    meaning: "持續追蹤（以使某事的結果更加成功）",
    example: "It is important to follow up an interview with a thank-you e-mail.",
    category: "人事",
    importance: 3
  },
  {
    text: "full-time",
    meaning: "全職的",
    example: "All full-time employees at this company receive benefits.",
    category: "人事",
    importance: 3
  },
  {
    text: "generate",
    meaning: "創造；造成；帶來；產生",
    example: "The ad generated only a few applications.",
    category: "人事",
    importance: 3
  },
  {
    text: "glass ceiling",
    meaning: "玻璃天花板；女性升遷障礙",
    example: "Susan didn't know there was a glass ceiling at her workplace until she hit it.",
    category: "人事",
    importance: 3
  },
  {
    text: "hardworking",
    meaning: "工作勤奮的",
    example: "I'm hardworking and organized, and I work well with others.",
    category: "人事",
    importance: 3
  },
  {
    text: "headhunter",
    meaning: "獵人頭公司",
    example: "I used to get a lot of headhunter calls when I worked as a manager for ABC company.",
    category: "人事",
    importance: 3
  },
  {
    text: "hesitant",
    meaning: "猶豫不決的",
    example: "I was a little hesitant to ask for a pay raise because I had only been with the company for a few months.",
    category: "人事",
    importance: 3
  },
  {
    text: "hire",
    meaning: "雇用；租借",
    example: "We need to hire some more office staff.",
    category: "人事",
    importance: 3
  },
  {
    text: "hiring criteria",
    meaning: "錄取標準",
    example: "How do we set hiring criteria?",
    category: "人事",
    importance: 3
  },
  {
    text: "human resources",
    meaning: "人力資源（部）；人事",
    example: "Someone from human resources will contact you soon to set up an interview.",
    category: "人事",
    importance: 3
  },
  {
    text: "in charge of",
    meaning: "負責",
    example: "I am in charge of training new staff.",
    category: "人事",
    importance: 3
  },
  {
    text: "incentive",
    meaning: "刺激；鼓勵；動機",
    example: "A lot of companies use incentive programs with their employees.",
    category: "人事",
    importance: 3
  },
  {
    text: "independently",
    meaning: "獨立地；自立地",
    example: "You have to be able to work independently.",
    category: "人事",
    importance: 3
  },
  {
    text: "intern",
    meaning: "實習生",
    example: "Three interns will be working with us this summer.",
    category: "人事",
    importance: 3
  },
  {
    text: "interviewee",
    meaning: "面試者；受訪者",
    example: "Most interviewees did not have enough experience for the position.",
    category: "人事",
    importance: 3
  },
  {
    text: "job description",
    meaning: "工作說明",
    example: "It's a good idea to read the job description carefully and ask questions before you take the job.",
    category: "人事",
    importance: 3
  },
  {
    text: "job fair",
    meaning: "徵才博覽會",
    example: "Dozens of technology companies will have representatives at the job fair.",
    category: "人事",
    importance: 3
  },
  {
    text: "job opening",
    meaning: "工作職缺",
    example: "I'm sorry. The job opening has been filled, but we'll keep your resume on file.",
    category: "人事",
    importance: 3
  },
  {
    text: "job-hopping",
    meaning: "跳槽",
    example: "Could job-hopping be good for your career?",
    category: "人事",
    importance: 3
  },
  {
    text: "lay off",
    meaning: "解雇；裁員",
    example: "I just heard that fifty people are going to be laid off next month.",
    category: "人事",
    importance: 3
  },
  {
    text: "leadership",
    meaning: "領導",
    example: "This advancement is a well-deserved recognition of your competent leadership.",
    category: "人事",
    importance: 3
  },
  {
    text: "leave without pay",
    meaning: "留職停薪；無薪假",
    example: "Jack has no more vacation days, so he took a week of leave without pay.",
    category: "人事",
    importance: 3
  },
  {
    text: "line of work",
    meaning: "行業",
    example: "What's your line of work?",
    category: "人事",
    importance: 3
  },
  {
    text: "lobby",
    meaning: "遊說；陳情",
    example: "It sounds like you are lobbying to fire the manager.",
    category: "人事",
    importance: 3
  },
  {
    text: "look forward to",
    meaning: "期待",
    example: "I'm looking forward to retiring. I won't miss working at all.",
    category: "人事",
    importance: 3
  },
  {
    text: "look to",
    meaning: "計畫；希望（做某事）",
    example: "They're looking to hire a lot of new staff in the new year.",
    category: "人事",
    importance: 3
  },
  {
    text: "loyal",
    meaning: "忠心的；忠誠的",
    example: "You have been a loyal employee, having worked in our company for over forty years.",
    category: "人事",
    importance: 3
  },
  {
    text: "match",
    meaning: "相當；匹配；和～相配；給（相等的錢）",
    example: "I'm hoping you can match the salary I had with my last company.",
    category: "人事",
    importance: 3
  },
  {
    text: "mentor",
    meaning: "指導者；良師",
    example: "I am so sad you are retiring because you are my mentor.",
    category: "人事",
    importance: 3
  },
  {
    text: "merit",
    meaning: "優點；價值；美德",
    example: "Your resume lists all your merits, but tell me what you think your biggest fault is.",
    category: "人事",
    importance: 3
  },
  {
    text: "move up",
    meaning: "提升；升職；提高地位",
    example: "She wants to move up in the company.",
    category: "人事",
    importance: 3
  },
  {
    text: "multitasking",
    meaning: "多重任務處理；多重任務執行",
    example: "Everyone lists multitasking as an ability on their resume, but few can truly do it.",
    category: "人事",
    importance: 3
  },
  {
    text: "notice",
    meaning: "公告；通知",
    example: "When I quit my job, if I give ten days' notice, would that be enough?",
    category: "人事",
    importance: 3
  },
  {
    text: "obviously",
    meaning: "明顯地；顯然",
    example: "She keeps asking for a pay raise; she obviously needs the money.",
    category: "人事",
    importance: 3
  },
  {
    text: "on board",
    meaning: "上任；加入",
    example: "A new financial director has been brought on board to help us evaluate the annual budgets.",
    category: "人事",
    importance: 3
  },
  {
    text: "on the basis of",
    meaning: "根據～",
    example: "You will be evaluated on the basis of how much you've contributed to the company.",
    category: "人事",
    importance: 3
  },
  {
    text: "on the road",
    meaning: "在旅途中；到處奔走",
    example: "Thomas will be on the road all week, so call his cell phone if you need to reach him.",
    category: "人事",
    importance: 3
  },
  {
    text: "on track",
    meaning: "有可能達成；步入正軌",
    example: "She's been working very hard recently and seems to be on track for a promotion.",
    category: "人事",
    importance: 3
  },
  {
    text: "on-the-job training",
    meaning: "在職訓練",
    example: "We didn't have any pre-job or on-the-job training.",
    category: "人事",
    importance: 3
  },
  {
    text: "overtime",
    meaning: "加班",
    example: "All overtime has to be approved by your supervisor and the HR Department.",
    category: "人事",
    importance: 3
  },
  {
    text: "paid vacation",
    meaning: "有薪年假",
    example: "New employees get one week of paid vacation after they have been with the company for one year.",
    category: "人事",
    importance: 3
  },
  {
    text: "paycheck",
    meaning: "薪資支票",
    example: "The HR assistant distributes employee paychecks every month.",
    category: "人事",
    importance: 3
  },
  {
    text: "pension",
    meaning: "退休金；津貼；補助金",
    example: "Mr. Parker is retiring after thirty years; he'll get a good pension.",
    category: "人事",
    importance: 3
  },
  {
    text: "performance",
    meaning: "表現",
    example: "What would your last boss say about your work performance?",
    category: "人事",
    importance: 3
  },
  {
    text: "personnel",
    meaning: "人員；員工；人事部",
    example: "Many of the factory personnel will lose their jobs.",
    category: "人事",
    importance: 3
  },
  {
    text: "pink slip",
    meaning: "解雇通知單",
    example: "HR handed out pink slips to fifteen employees last month.",
    category: "人事",
    importance: 3
  },
  {
    text: "position",
    meaning: "職務；職位",
    example: "Do you have any questions about the position?",
    category: "人事",
    importance: 3
  },
  {
    text: "probationary period",
    meaning: "試用期",
    example: "New employees undergo a one-month probationary period.",
    category: "人事",
    importance: 3
  },
  {
    text: "proficient",
    meaning: "精通的",
    example: "I'm proficient in word processing.",
    category: "人事",
    importance: 3
  },
  {
    text: "profile",
    meaning: "個人簡介；輪廓；外形",
    example: "Please include a short profile with your resume.",
    category: "人事",
    importance: 3
  },
  {
    text: "promote",
    meaning: "升遷；推銷；宣傳",
    example: "She has recently been promoted to manager.",
    category: "人事",
    importance: 3
  },
  {
    text: "prospective",
    meaning: "預期的；未來的",
    example: "An experienced interviewer can spot inefficient prospective employees.",
    category: "人事",
    importance: 3
  },
  {
    text: "qualification",
    meaning: "資格；資格證明；證照；條件",
    example: "We will choose the person with the best qualifications for this position.",
    category: "人事",
    importance: 3
  },
  {
    text: "recognition",
    meaning: "公開表揚；認可",
    example: "The company threw a retirement party for him in recognition of his many years of hard work.",
    category: "人事",
    importance: 3
  },
  {
    text: "recruit",
    meaning: "招募；招收",
    example: "The company likes to recruit people straight out of school.",
    category: "人事",
    importance: 3
  },
  {
    text: "reject",
    meaning: "拒絕；駁回；排斥",
    example: "His application was rejected because he doesn't have a college degree.",
    category: "人事",
    importance: 3
  },
  {
    text: "relocate",
    meaning: "調職",
    example: "Ten staff members chose to relocate to Taipei.",
    category: "人事",
    importance: 3
  },
  {
    text: "replace",
    meaning: "取代；代替",
    example: "There is money in the budget to replace the old photocopier on the fourth floor.",
    category: "人事",
    importance: 3
  },
  {
    text: "report to",
    meaning: "直屬",
    example: "You report to the HR Director.",
    category: "人事",
    importance: 3
  },
  {
    text: "reshuffle",
    meaning: "改組；改革；洗牌",
    example: "The CEO decided to reshuffle the company's top management.",
    category: "人事",
    importance: 3
  },
  {
    text: "resignation",
    meaning: "辭職",
    example: "The sudden resignation of the vice-president came as a shock.",
    category: "人事",
    importance: 3
  },
  {
    text: "resume",
    meaning: "履歷表",
    example: "Your resume says you've worked at a number of companies.",
    category: "人事",
    importance: 3
  },
  {
    text: "retire",
    meaning: "退休；撤退",
    example: "I hope I don't get bored when I retire.",
    category: "人事",
    importance: 3
  },
  {
    text: "salary",
    meaning: "薪水；薪資",
    example: "Your health insurance payment comes straight out of your salary every month.",
    category: "人事",
    importance: 3
  },
  {
    text: "seniority",
    meaning: "資歷；資深",
    example: "She has the experience and seniority to handle it.",
    category: "人事",
    importance: 3
  },
  {
    text: "severance pay",
    meaning: "資遣費",
    example: "Bill decided to quit, so he was not entitled to any severance pay.",
    category: "人事",
    importance: 3
  },
  {
    text: "sex discrimination",
    meaning: "性別歧視",
    example: "Is there sex discrimination in your company?",
    category: "人事",
    importance: 3
  },
  {
    text: "specialize",
    meaning: "專精於；專攻；使特殊化",
    example: "Nathan specializes in helping the elderly become computer literate.",
    category: "人事",
    importance: 3
  },
  {
    text: "strong point",
    meaning: "優點",
    example: "What are your weak and strong points?",
    category: "人事",
    importance: 3
  },
  {
    text: "successor",
    meaning: "繼任者；繼承人",
    example: "Who is the likely successor to Mr. Brown after his retirement?",
    category: "人事",
    importance: 3
  },
  {
    text: "suspension",
    meaning: "停職；暫停；中止",
    example: "The suspension of our license will last until we pay the new registration fees.",
    category: "人事",
    importance: 3
  },
  {
    text: "take over",
    meaning: "接替；接管",
    example: "My assistant can take over until we get somebody.",
    category: "人事",
    importance: 3
  },
  {
    text: "temp",
    meaning: "臨時僱員",
    example: "We need to get a temp to help us catch up.",
    category: "人事",
    importance: 3
  },
  {
    text: "time-consuming",
    meaning: "費時的",
    example: "Reading all the applications can be so timeconsuming.",
    category: "人事",
    importance: 3
  },
  {
    text: "track record",
    meaning: "績效紀錄",
    example: "Partner Investments is hiring brokers with great investment track records.",
    category: "人事",
    importance: 3
  },
  {
    text: "turnover",
    meaning: "員工流動率；貨物流通率",
    example: "Retail companies have a high turnover rate for employees.",
    category: "人事",
    importance: 3
  },
  {
    text: "unemployment rate",
    meaning: "失業率",
    example: "The unemployment rate remained at 4.5%.",
    category: "人事",
    importance: 3
  },
  {
    text: "update",
    meaning: "使～知道最新資訊；更新",
    example: "Your resume only goes up to the end of last year; can you update me on what you have been doing recently?",
    category: "人事",
    importance: 3
  },
  {
    text: "value",
    meaning: "重視；珍惜；評價",
    example: "We will miss Terry; we valued her as a coworker and a friend.",
    category: "人事",
    importance: 3
  },
  {
    text: "wage",
    meaning: "薪水；報酬",
    example: "I want a fair wage for this new position.",
    category: "人事",
    importance: 3
  },
  {
    text: "working hours",
    meaning: "工作時間",
    example: "Working hours are from nine to five.",
    category: "人事",
    importance: 3
  },
  {
    text: "abundant",
    meaning: "大量的；豐富的",
    example: "The wholesaler offers an abundant selection.",
    category: "採購",
    importance: 3
  },
  {
    text: "accurately",
    meaning: "準確地；精準地",
    example: "Invoices must be written accurately, otherwise we could lose money.",
    category: "採購",
    importance: 3
  },
  {
    text: "accustomed",
    meaning: "慣常的",
    example: "We're accustomed to basing fees on the export price.",
    category: "採購",
    importance: 3
  },
  {
    text: "acquaintance",
    meaning: "熟人；認識的人",
    example: "We always give an acquaintance a cheaper price.",
    category: "採購",
    importance: 3
  },
  {
    text: "adjustment",
    meaning: "調整",
    example: "You promised me a discount, so can you make an adjustment on the invoice, please?",
    category: "採購",
    importance: 3
  },
  {
    text: "apologize",
    meaning: "道歉；認錯",
    example: "We apologize for the delay in getting back to you.",
    category: "採購",
    importance: 3
  },
  {
    text: "appliance",
    meaning: "器材；用具；設備",
    example: "We sell top-of-the-line appliances from air conditioners to refrigerators.",
    category: "採購",
    importance: 3
  },
  {
    text: "assure",
    meaning: "向～保證；擔保",
    example: "I can assure you of the quality of the product.",
    category: "採購",
    importance: 3
  },
  {
    text: "automatically",
    meaning: "自動地",
    example: "Our computer system automatically tells us when we need to order more supplies.",
    category: "採購",
    importance: 3
  },
  {
    text: "bill of lading",
    meaning: "提單",
    example: "There are many types of bills of lading.",
    category: "採購",
    importance: 3
  },
  {
    text: "buyers' guide",
    meaning: "買家指南",
    example: "This online buyers' guide has the latest information on houseware products.",
    category: "採購",
    importance: 3
  },
  {
    text: "carriage free",
    meaning: "免付運費",
    example: "Carriage free delivery is available on every order over $10,000.",
    category: "採購",
    importance: 3
  },
  {
    text: "carrier",
    meaning: "運輸公司；運送者",
    example: "We can ship it out tomorrow, but which carrier do you want to use?",
    category: "採購",
    importance: 3
  },
  {
    text: "carry",
    meaning: "有出售；備有（貨品）",
    example: "Home electronics stores usually carry several brands to choose from.",
    category: "採購",
    importance: 3
  },
  {
    text: "cash on delivery",
    meaning: "貨到付現",
    example: "I'm not opposed to cash on delivery.",
    category: "採購",
    importance: 3
  },
  {
    text: "catalog",
    meaning: "目錄；型錄；清單",
    example: "I would like to order something I saw in your catalog.",
    category: "採購",
    importance: 3
  },
  {
    text: "chain store",
    meaning: "連鎖店",
    example: "That item is sold in several chain stores.",
    category: "採購",
    importance: 3
  },
  {
    text: "checkout",
    meaning: "商店的結帳處；檢查；（旅館）退房（時間）",
    example: "I got to the checkout and then found that I didn't have any money on me!",
    category: "採購",
    importance: 3
  },
  {
    text: "commodity",
    meaning: "商品",
    example: "The price of commodities such as rice is increasing rapidly.",
    category: "採購",
    importance: 3
  },
  {
    text: "compile",
    meaning: "收集整理；彙編",
    example: "We're just compiling your invoices now, and we will send them to you as soon as we're finished.",
    category: "採購",
    importance: 3
  },
  {
    text: "complaint",
    meaning: "抱怨；投訴；抗議",
    example: "I recently got a complaint from one of our longtime customers.",
    category: "採購",
    importance: 3
  },
  {
    text: "consignee",
    meaning: "收件人；收貨人",
    example: "The package will be returned if there is an error in the consignee's address.",
    category: "採購",
    importance: 3
  },
  {
    text: "consumer base",
    meaning: "消費群",
    example: "We are trying to expand our consumer base by cutting the price.",
    category: "採購",
    importance: 3
  },
  {
    text: "coupon",
    meaning: "優惠券",
    example: "My sister collects a lot of coupons from the newspaper.",
    category: "採購",
    importance: 3
  },
  {
    text: "credit",
    meaning: "把～記入（帳戶或貸方等）；把～歸因於",
    example: "The refund will be credited to your account within a month.",
    category: "採購",
    importance: 3
  },
  {
    text: "crucial",
    meaning: "極重要的；要緊的",
    example: "It's crucial that we receive these supplies before Christmas.",
    category: "採購",
    importance: 3
  },
  {
    text: "customer",
    meaning: "顧客；客戶",
    example: "If a store has no customers, it will make no money.",
    category: "採購",
    importance: 3
  },
  {
    text: "dealer",
    meaning: "業者；商人",
    example: "The used-car dealer sold us a car for a very reasonable price.",
    category: "採購",
    importance: 3
  },
  {
    text: "delivery",
    meaning: "傳送；傳遞",
    example: "We are waiting for the delivery of the goods.",
    category: "採購",
    importance: 3
  },
  {
    text: "discount",
    meaning: "折扣",
    example: "What kind of discount can you give me on an order of one thousand?",
    category: "採購",
    importance: 3
  },
  {
    text: "discrepancy",
    meaning: "不一致；不符；差異",
    example: "There is a discrepancy between what the price tag shows and what you are charging me.",
    category: "採購",
    importance: 3
  },
  {
    text: "efficient",
    meaning: "有效率的",
    example: "I replaced all the old light bulbs in my house with more energy efficient ones.",
    category: "採購",
    importance: 3
  },
  {
    text: "erratic",
    meaning: "不穩定的；無規律的",
    example: "The price of cotton has been erratic.",
    category: "採購",
    importance: 3
  },
  {
    text: "essentially",
    meaning: "基本上；本質上",
    example: "Essentially, we need your order by the 7th if you want to receive the goods by the end of the month.",
    category: "採購",
    importance: 3
  },
  {
    text: "estimate",
    meaning: "估計；估量；估價單",
    example: "Can you give me an estimate of the delivery time?",
    category: "採購",
    importance: 3
  },
  {
    text: "exclusive",
    meaning: "獨家的",
    example: "We'd like exclusive distribution rights.",
    category: "採購",
    importance: 3
  },
  {
    text: "expect",
    meaning: "預期；期待",
    example: "You can expect the shipment within seven working days.",
    category: "採購",
    importance: 3
  },
  {
    text: "fail to",
    meaning: "未達成（預期的事）",
    example: "The florist failed to bring the flowers on time, so I don't think we should pay him.",
    category: "採購",
    importance: 3
  },
  {
    text: "feedback",
    meaning: "意見回饋",
    example: "Be sure to check the seller's feedback rating before buying anything online.",
    category: "採購",
    importance: 3
  },
  {
    text: "flaw",
    meaning: "缺點；瑕疵；使有缺陷",
    example: "There's an obvious flaw in this product design.",
    category: "採購",
    importance: 3
  },
  {
    text: "fluctuate",
    meaning: "波動；震盪",
    example: "Fruit prices fluctuate with the seasons.",
    category: "採購",
    importance: 3
  },
  {
    text: "fragile",
    meaning: "易碎的",
    example: "Fragile items inside. Please handle with care.",
    category: "採購",
    importance: 3
  },
  {
    text: "freight",
    meaning: "運費",
    example: "The basic model is listed for $8,500 plus $250 freight.",
    category: "採購",
    importance: 3
  },
  {
    text: "fulfill",
    meaning: "達到（目的）；履行（諾言）；滿足（願望）",
    example: "Will you be able to fulfill our order?",
    category: "採購",
    importance: 3
  },
  {
    text: "going rate",
    meaning: "現行價格；目前的行情",
    example: "It's still higher than the going rate.",
    category: "採購",
    importance: 3
  },
  {
    text: "guarantee",
    meaning: "（商品）保證；保證書",
    example: "The store guaranteed my DVD player for two years.",
    category: "採購",
    importance: 3
  },
  {
    text: "impose",
    meaning: "徵收；加（負擔）於；把～強加於",
    example: "As you are paying the invoice late, we have to impose a small fine.",
    category: "採購",
    importance: 3
  },
  {
    text: "in bulk",
    meaning: "大量",
    example: "The office buys paper in bulk to reduce costs.",
    category: "採購",
    importance: 3
  },
  {
    text: "integral",
    meaning: "不可或缺的；整體的",
    example: "Sending out and paying invoices is an integral part of doing business.",
    category: "採購",
    importance: 3
  },
  {
    text: "invoice",
    meaning: "發票",
    example: "The number of your purchase order is in the lefthand corner of your invoice.",
    category: "採購",
    importance: 3
  },
  {
    text: "item",
    meaning: "項目；品項",
    example: "The iPhone is this year's must-have item.",
    category: "採購",
    importance: 3
  },
  {
    text: "lead time",
    meaning: "交期；前置時間",
    example: "We need a lead time of two weeks for large orders.",
    category: "採購",
    importance: 3
  },
  {
    text: "letter of credit",
    meaning: "信用狀",
    example: "Our customers usually pay by letter of credit.",
    category: "採購",
    importance: 3
  },
  {
    text: "liability",
    meaning: "責任；義務",
    example: "What is your liability if the order is lost or broken in shipping?",
    category: "採購",
    importance: 3
  },
  {
    text: "lump sum",
    meaning: "一次付清（的款項）",
    example: "Is it possible for you to pay in one lump sum?",
    category: "採購",
    importance: 3
  },
  {
    text: "mail order",
    meaning: "郵購",
    example: "Our products are available by mail order.",
    category: "採購",
    importance: 3
  },
  {
    text: "maintain",
    meaning: "維持；保持；供養；維修",
    example: "You can usually get better prices and service if you maintain a good relationship with the supplier.",
    category: "採購",
    importance: 3
  },
  {
    text: "mandatory",
    meaning: "命令的；義務的；強制性的",
    example: "Shipping insurance is mandatory and included in the price.",
    category: "採購",
    importance: 3
  },
  {
    text: "max out",
    meaning: "刷爆",
    example: "My husband has maxed out three credit cards online.",
    category: "採購",
    importance: 3
  },
  {
    text: "merchandise",
    meaning: "商品（不可數）",
    example: "When will our merchandise arrive?",
    category: "採購",
    importance: 3
  },
  {
    text: "minimize",
    meaning: "使減到最少；使縮到最小",
    example: "Shipping the order out on Monday will minimize the shipping time.",
    category: "採購",
    importance: 3
  },
  {
    text: "mistake",
    meaning: "錯誤；誤會",
    example: "There's a mistake on this invoice; we have already paid for some of these.",
    category: "採購",
    importance: 3
  },
  {
    text: "net weight",
    meaning: "淨重",
    example: "All of our prices are based on the net weight of the product, which excludes packaging.",
    category: "採購",
    importance: 3
  },
  {
    text: "notify",
    meaning: "正式通知；告知",
    example: "We'll notify our customer base of our new products.",
    category: "採購",
    importance: 3
  },
  {
    text: "obtain",
    meaning: "獲得；得到",
    example: "I need to obtain a freeparking ticket.",
    category: "採購",
    importance: 3
  },
  {
    text: "on hand",
    meaning: "馬上可用的；在手邊的",
    example: "We keep most supplies on hand, but sometimes we still need to make special orders.",
    category: "採購",
    importance: 3
  },
  {
    text: "open account",
    meaning: "記帳交易",
    example: "Many companies consider open account sales very risky.",
    category: "採購",
    importance: 3
  },
  {
    text: "order",
    meaning: "訂購；訂貨；點餐",
    example: "Have you received your order from that company yet?",
    category: "採購",
    importance: 3
  },
  {
    text: "outrageous",
    meaning: "荒唐的；駭人聽聞的",
    example: "These prices are outrageous!",
    category: "採購",
    importance: 3
  },
  {
    text: "packing list",
    meaning: "裝箱單；送貨明細",
    example: "The destination contact details must be included on the packing list.",
    category: "採購",
    importance: 3
  },
  {
    text: "pallet",
    meaning: "（裝卸、搬運貨物用的）貨板",
    example: "The warehouse can hold more than 100 thousand pallets.",
    category: "採購",
    importance: 3
  },
  {
    text: "parcel",
    meaning: "包裹",
    example: "Parcels over seventy pounds require oversized rates.",
    category: "採購",
    importance: 3
  },
  {
    text: "partner",
    meaning: "與～合作（或合夥）；合夥人",
    example: "The government has partnered with local organizations to supply clean drinking water.",
    category: "採購",
    importance: 3
  },
  {
    text: "pay on/upon delivery",
    meaning: "貨到付款",
    example: "Our policy clearly states that customers must pay on delivery.",
    category: "採購",
    importance: 3
  },
  {
    text: "payment in advance",
    meaning: "預先付款",
    example: "A discount will be given if the buyer makes payment in advance.",
    category: "採購",
    importance: 3
  },
  {
    text: "payment terms",
    meaning: "付款條件",
    example: "I'd like to know what payment terms you'd accept.",
    category: "採購",
    importance: 3
  },
  {
    text: "peak",
    meaning: "高峰；頂端；最高點",
    example: "The price of raw materials hit a peak at the end of the summer.",
    category: "採購",
    importance: 3
  },
  {
    text: "preferential price",
    meaning: "優惠價格",
    example: "Body Gym gives preferential prices to its members.",
    category: "採購",
    importance: 3
  },
  {
    text: "prerequisite",
    meaning: "首要事務；前提；先決條件",
    example: "Knowing what you want and how much you want to pay is a prerequisite to a happy shopping experience.",
    category: "採購",
    importance: 3
  },
  {
    text: "price war",
    meaning: "價格戰；削價競爭",
    example: "The neighboring gas stations started a price war on gasoline.",
    category: "採購",
    importance: 3
  },
  {
    text: "procurement",
    meaning: "採購；取得",
    example: "The procurement of all the necessary parts is going to be a headache!",
    category: "採購",
    importance: 3
  },
  {
    text: "promptly",
    meaning: "立刻；無延誤地",
    example: "I ordered the supplies and they promptly arrived the next day.",
    category: "採購",
    importance: 3
  },
  {
    text: "purchase",
    meaning: "買；購買",
    example: "Our company is purchasing new computers.",
    category: "採購",
    importance: 3
  },
  {
    text: "quality",
    meaning: "品質；等級；特質",
    example: "Swiss watches are famous for their quality.",
    category: "採購",
    importance: 3
  },
  {
    text: "quantity",
    meaning: "數量；數額",
    example: "Do you think you can increase the quantity of your order?",
    category: "採購",
    importance: 3
  },
  {
    text: "rack",
    meaning: "架子；掛物架",
    example: "The items on sale are all on this rack.",
    category: "採購",
    importance: 3
  },
  {
    text: "rebate",
    meaning: "折扣；貼現；退還部分付款",
    example: "To get the $50 rebate, simply bring this coupon to the store.",
    category: "採購",
    importance: 3
  },
  {
    text: "receipt",
    meaning: "收據",
    example: "The store asks for a receipt when customers want to return or exchange products.",
    category: "採購",
    importance: 3
  },
  {
    text: "rectify",
    meaning: "矯正；改正",
    example: "You sent us the wrong order. How will you rectify the situation?",
    category: "採購",
    importance: 3
  },
  {
    text: "reflect",
    meaning: "反映",
    example: "The cost of our products reflects their quality.",
    category: "採購",
    importance: 3
  },
  {
    text: "refund",
    meaning: "退款",
    example: "If you're not satisfied, we have a one-week no-questions-asked refund policy.",
    category: "採購",
    importance: 3
  },
  {
    text: "remember",
    meaning: "記得",
    example: "Did you remember to order the copy paper?",
    category: "採購",
    importance: 3
  },
  {
    text: "repair",
    meaning: "修理；修補",
    example: "They said they would repair the photocopier by Thursday.",
    category: "採購",
    importance: 3
  },
  {
    text: "reserve price",
    meaning: "底價",
    example: "The reserve price is way higher than I expected.",
    category: "採購",
    importance: 3
  },
  {
    text: "restock",
    meaning: "補貨；重新進貨",
    example: "Our supplier went out of business, so we haven't been able to restock that item.",
    category: "採購",
    importance: 3
  },
  {
    text: "run",
    meaning: "管理；經營",
    example: "I started out preparing invoices two years ago, and now I run the whole office.",
    category: "採購",
    importance: 3
  },
  {
    text: "rush order",
    meaning: "緊急訂單；急件",
    example: "Even if we put a rush order on shipment by sea, we still may not make it.",
    category: "採購",
    importance: 3
  },
  {
    text: "scan",
    meaning: "掃瞄；細看；審視",
    example: "All of the boxes are scanned as they leave the factory.",
    category: "採購",
    importance: 3
  },
  {
    text: "shipment",
    meaning: "貨運物；貨運",
    example: "Can you pay in advance of shipment?",
    category: "採購",
    importance: 3
  },
  {
    text: "strictly",
    meaning: "嚴格地；完全地；僅僅",
    example: "The lower price is strictly for those invoices paid on time.",
    category: "採購",
    importance: 3
  },
  {
    text: "subtract",
    meaning: "減掉；扣掉",
    example: "We didn't receive these, so you need to subtract them from the bill.",
    category: "採購",
    importance: 3
  },
  {
    text: "supply",
    meaning: "供應",
    example: "This is the company that supplies our computer equipment.",
    category: "採購",
    importance: 3
  },
  {
    text: "surcharge",
    meaning: "額外費用；對～收取附加費",
    example: "Is this simply the charge for the product or does it include the surcharges as well?",
    category: "採購",
    importance: 3
  },
  {
    text: "tempt",
    meaning: "誘惑；慫恿；打動",
    example: "I was tempted to buy that brand name bag, but I didn't.",
    category: "採購",
    importance: 3
  },
  {
    text: "term",
    meaning: "條件；條款；期限；術語",
    example: "According to the terms listed on our invoice, if you cancel, you still have to pay half of the total.",
    category: "採購",
    importance: 3
  },
  {
    text: "throw in",
    meaning: "外加；額外贈送",
    example: "Since you ordered so many flowers, I'll throw in some roses for you.",
    category: "採購",
    importance: 3
  },
  {
    text: "transfer inventory",
    meaning: "調貨",
    example: "If one store runs out, we can quickly transfer inventory from another store.",
    category: "採購",
    importance: 3
  },
  {
    text: "trend",
    meaning: "趨勢；時尚",
    example: "Shopping trends show what kinds of things people buy and when.",
    category: "採購",
    importance: 3
  },
  {
    text: "vendor",
    meaning: "供應商；賣主",
    example: "We plan to buy 300 units from that vendor.",
    category: "採購",
    importance: 3
  },
  {
    text: "verify",
    meaning: "確認；查證",
    example: "Can you verify that the order will arrive by the end of the week?",
    category: "採購",
    importance: 3
  },
  {
    text: "waive",
    meaning: "放棄（權力、要求等）；撤回",
    example: "If you can commit to an order of 100 or more pieces, we'll waive the shipping fee.",
    category: "採購",
    importance: 3
  },
  {
    text: "warranty",
    meaning: "保證書；擔保",
    example: "Parts and labor are covered by a two-year warranty.",
    category: "採購",
    importance: 3
  },
  {
    text: "worth",
    meaning: "值得的；價值",
    example: "Sure it's expensive, but believe me, it's worth every penny!",
    category: "採購",
    importance: 3
  },
  {
    text: "access",
    meaning: "存取；取得的方法；門路；入口",
    example: "We now have access to the Internet.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "back up",
    meaning: "（檔案、資料等）備份",
    example: "You need to back up your important files regularly.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "beta",
    meaning: "【電腦】（程式尚未正式完成的）試用版",
    example: "We selected 100 customers to try out the beta version of the software.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "blog",
    meaning: "部落格",
    example: "I'm always careful not to put personal information on my blog.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "bookmark",
    meaning: "加入書籤",
    example: "Don't forget to bookmark this page.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "broadband",
    meaning: "寬頻",
    example: "The company is planning to test high speed broadband networks in China.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "browse",
    meaning: "瀏覽",
    example: "I came across this interesting Web site when I was browsing the Internet.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "bug",
    meaning: "（系統或程式的）瑕疵或錯誤",
    example: "The engineers worked all night to fix the software bug.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "cable",
    meaning: "電纜；有線電視",
    example: "Your computer is connected to the printer by a black cable.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "capacity",
    meaning: "容量",
    example: "The capacity of the network's server was recently increased.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "chip",
    meaning: "晶片；積體電路片",
    example: "This computer chip is programmed for use in cell phones.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "community",
    meaning: "社群",
    example: "This blog has a huge user community.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "companywide",
    meaning: "全公司地",
    example: "The boss decided to replace all computers companywide.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "connectivity",
    meaning: "（網路）連接",
    example: "The building doesn't have any Internet connectivity, but it can be installed quickly.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "copyright",
    meaning: "版權；著作權",
    example: "Anything you publish on the Internet automatically has copyright protection.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "crash",
    meaning: "當機",
    example: "My computer crashed!",
    category: "技術層面",
    importance: 3
  },
  {
    text: "database",
    meaning: "資料庫；數據庫",
    example: "My department maintains a database on all our customers over the past twenty years.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "defragment",
    meaning: "磁碟重整",
    example: "I want to defragment my disk.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "desktop",
    meaning: "桌上型電腦",
    example: "I use a desktop computer in the office.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "digital",
    meaning: "數位的；數字的",
    example: "Almost everyone has a digital camera nowadays.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "down",
    meaning: "當機；無法運作",
    example: "The servers are down.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "download",
    meaning: "下載",
    example: "Why is this file taking so long to download?",
    category: "技術層面",
    importance: 3
  },
  {
    text: "e-commerce",
    meaning: "電子商務",
    example: "Using e-commerce to do business is very popular right now.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "experimental",
    meaning: "實驗性的；試驗性的",
    example: "My boss set up an experimental co-op program through the university.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "filename",
    meaning: "檔名",
    example: "Do you remember the filename?",
    category: "技術層面",
    importance: 3
  },
  {
    text: "folder",
    meaning: "檔案夾",
    example: "Why did I save it in that folder? No wonder I couldn't find it.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "formula",
    meaning: "方程式；處方；配方",
    example: "You'll be in for a surprise when you try our new improved formula.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "Frequently Asked Questions",
    meaning: "常見問題",
    example: "Here is a brochure with a list of Frequently Asked Questions.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "get online",
    meaning: "上網",
    example: "All you have to do to get online is click on this button.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "go live",
    meaning: "（網站）正式上線",
    example: "Our new Web site is going to go live next Wednesday.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "graphics file",
    meaning: "圖檔",
    example: "The extension on this file means that it is a graphics file.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "hard drive",
    meaning: "硬碟",
    example: "If you're really out of disk space, you'll need a new hard drive.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "homepage",
    meaning: "（網路）首頁",
    example: "Click on the symbol that looks like a house to go to the homepage.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "hypothesis",
    meaning: "假說；前提",
    example: "Our hypothesis was that older people prefer simple designs.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "infect",
    meaning: "感染（電腦病毒或疾病）",
    example: "My brother isn't careful, so his computer gets infected with a virus every few months.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "input method",
    meaning: "輸入法",
    example: "Boshiamy is one of the fastest Chinese input methods.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "insight",
    meaning: "洞察力；眼光；深刻的理解",
    example: "The discovery gave scientists insight into the human mind.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "interface",
    meaning: "界面",
    example: "Many people appreciate Apple's user-friendly interface.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "Internet connection",
    meaning: "網路連線",
    example: "The Internet connection slows down considerably in the evening after seven p.m.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "key combination",
    meaning: "組合功能鍵",
    example: "You can press key combinations such as ctrl-altdelete to log on or alt-F4 to shut down.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "key command",
    meaning: "鍵盤指令",
    example: "The engineers tried to keep the key commands short and easy to remember.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "keyboard",
    meaning: "鍵盤",
    example: "If you spend all day typing, you should get an ergonomic keyboard.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "laboratory",
    meaning: "實驗室；研究室",
    example: "Large companies can afford to have their own testing laboratories.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "laptop",
    meaning: "筆記型電腦",
    example: "Alan needed a portable computer, so he bought a laptop.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "link",
    meaning: "（網站）連結",
    example: "Click on this link to open the web page.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "log on",
    meaning: "登入",
    example: "You need your password to log on.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "login",
    meaning: "【電腦】登錄；進入系統",
    example: "Press ctrl-tab to begin the login process.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "magnifying glass",
    meaning: "放大鏡",
    example: "The inspectors put our entire factory under a magnifying glass.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "memory",
    meaning: "記憶體",
    example: "I need more memory to run this program.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "memory capacity",
    meaning: "記憶體容量",
    example: "My computer doesn't have the memory capacity to store these movies.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "microscope",
    meaning: "顯微鏡",
    example: "The technician spends his day looking at blood samples with a microscope.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "monitor",
    meaning: "螢幕；監控；監測",
    example: "A good monitor is important if you look at a computer all day as part of your job.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "network",
    meaning: "網路；聯播網",
    example: "A computer network allows you to see files on other people's computers.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "offline",
    meaning: "離線的",
    example: "The servers were offline all morning.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "online",
    meaning: "連線的",
    example: "You can access the network now. The servers are back online.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "online auction",
    meaning: "網路拍賣",
    example: "eBay is one of the leading online auction houses worldwide.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "operating system",
    meaning: "作業系統",
    example: "Please contact the IT department if you need changes made to your computer's operating system.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "outdated",
    meaning: "過時的；退流行的",
    example: "The computer system is outdated; we need to get a new one.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "phase",
    meaning: "階段；時期",
    example: "The experiment is still in the early phase.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "platform",
    meaning: "平台",
    example: "My company is about to launch an online gaming platform.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "plug",
    meaning: "插上插頭；插頭",
    example: "I need to plug in my notebook computer in order to charge its battery.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "pop up",
    meaning: "突然出現；跳出來",
    example: "This screen keeps popping up saying I have no more disk space.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "power button",
    meaning: "電源按鈕；電源鍵",
    example: "You forgot to push the power button.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "remainder",
    meaning: "剩下的部分；（數學）餘數",
    example: "We sold 800 Christmas trees and stored the remainder until next year.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "restart",
    meaning: "重新開機",
    example: "Restart your computer and try again.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "retrieval",
    meaning: "取回；恢復",
    example: "File retrieval only takes a couple of seconds on the new server.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "revolution",
    meaning: "革命；革命運動",
    example: "The Internet has created a revolution in the way we communicate.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "robot",
    meaning: "機器人",
    example: "The robot has a computer for a brain.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "rollout",
    meaning: "首次展示",
    example: "The rollout of the new product line will take place in September.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "search",
    meaning: "搜尋",
    example: "Let's run a search through Google.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "sequence",
    meaning: "連續；順序；一連串",
    example: "It's important to follow all the steps in sequence.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "serial number",
    meaning: "序號",
    example: "The serial number for the new software is located on the installation disk.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "server",
    meaning: "【電腦】伺服器",
    example: "All of the servers are kept in a special air-conditioned room.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "short circuit",
    meaning: "短路",
    example: "A short circuit in the motherboard caused the computer to crash.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "shortcut",
    meaning: "捷徑",
    example: "Press F1 to get a list of all the shortcuts for this program.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "socket",
    meaning: "【電】插座；插口",
    example: "Please plug this cord into the socket on the back of the computer.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "software",
    meaning: "軟體",
    example: "Purchasing software for all the computers can be very expensive.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "substitute",
    meaning: "代替（品）",
    example: "Being careful is no substitute for regularly backing up your files.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "technician",
    meaning: "技術人員；技師",
    example: "The rental company sent over a technician to fix our photocopier.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "telescope",
    meaning: "望遠鏡",
    example: "Our CEO keeps a telescope in his office to look at the stars at night.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "text file",
    meaning: "文字檔",
    example: "To transfer files between programs, first save them as text files.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "top-of-the-line",
    meaning: "頂級的；最先進的",
    example: "The equipment in the testing lab is all top-of-the-line.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "up and running",
    meaning: "正常運作中",
    example: "Do you know if the servers are up and running yet?",
    category: "技術層面",
    importance: 3
  },
  {
    text: "update",
    meaning: "更新",
    example: "You need to update your anti-virus software.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "upgrade",
    meaning: "升級",
    example: "You can upgrade to the new version of the software for fifty dollars.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "user name",
    meaning: "使用者名稱",
    example: "Make sure that your user name is simple and easy to remember.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "virus",
    meaning: "病毒",
    example: "Your computer has been infected with a virus.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "wi-fi",
    meaning: "無線網路",
    example: "The cafe offers wi-fi access for laptop users.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "wireless",
    meaning: "無線的",
    example: "Wireless mice are more expensive, but they are very convenient to use.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "wizard",
    meaning: "高手；奇才",
    example: "Bill is a computer wizard.",
    category: "技術層面",
    importance: 3
  },
  {
    text: "acre",
    meaning: "英畝",
    example: "Tim bought ten acres of land near the lake.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "amenity",
    meaning: "（環境等的）舒適 ；便利設施",
    example: "My new apartment is close to all the amenities.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "antenna",
    meaning: "天線；觸鬚",
    example: "There's a big antenna on the roof, but I don't know what it's for.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "architecture",
    meaning: "建築物；建築構造",
    example: "Steven has always wanted to study architecture.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "attic",
    meaning: "閣樓",
    example: "We keep old clothes and pictures in the attic.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "balcony",
    meaning: "陽台",
    example: "Jim likes to sit on his balcony and relax.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "basement",
    meaning: "地下室",
    example: "We keep many boxes in the basement.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "block",
    meaning: "街區",
    example: "If you go one block east you'll hit Maple Drive.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "bookcase",
    meaning: "書櫃",
    example: "The bookcase was too weak.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "brand-new",
    meaning: "全新的",
    example: "This is a brand-new office building.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "brick",
    meaning: "磚塊；用磚砌",
    example: "The house is made of bricks.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "broom",
    meaning: "掃帚",
    example: "Cathy used a broom to sweep up the broken glass on the floor.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "bucket",
    meaning: "水桶",
    example: "Adam poured a bucket of water into the tub.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "burglar alarm",
    meaning: "防盜警鈴",
    example: "I forgot to set the burglar alarm when I left the house.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "cabinet",
    meaning: "（有抽屜或格子的）櫥櫃",
    example: "Bill bought a stereo cabinet for his stereo.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "carpet",
    meaning: "地毯",
    example: "Jane has a carpet in her living room.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "cellar",
    meaning: "酒窖",
    example: "The old house had a wine cellar, where hundreds of bottles were kept.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "cement",
    meaning: "水泥",
    example: "He accidentally stepped in the wet cement.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "closet",
    meaning: "衣櫃；壁櫥",
    example: "Peter put all his clothes in the closet.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "collapse",
    meaning: "倒塌；崩潰；瓦解",
    example: "The old apartment building collapsed during the earthquake.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "complex",
    meaning: "複合物；綜合設施",
    example: "Randall lives in a high-end apartment complex.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "concrete",
    meaning: "混凝土",
    example: "The concrete is still wet, so please don't walk on it.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "condominium",
    meaning: "（各戶有獨立產權的）公寓大廈",
    example: "I'd like to buy a condominium, but I can't afford one in this neighborhood.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "construction",
    meaning: "建造；建設",
    example: "The construction company has built a lot of commercial buildings.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "convenient",
    meaning: "方便的；便利的；（口語）靠近的",
    example: "Taipei is a very convenient place to live.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "couch",
    meaning: "沙發",
    example: "I need to buy some furniture, like a desk, a chair, and a couch.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "crane",
    meaning: "起重機；吊車",
    example: "An enormous crane was used to lift the heavy pieces of the bridge that was being built.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "credit history",
    meaning: "信用紀錄",
    example: "You'll need a good credit history to get the loan.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "cupboard",
    meaning: "碗櫥",
    example: "Will you get me a plate from the cupboard?",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "decoration",
    meaning: "裝潢；裝飾",
    example: "I like the decoration of this house.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "district",
    meaning: "行政區；特區",
    example: "Many banks are located in the financial district of the city.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "downtown",
    meaning: "市中心",
    example: "Downtown is an expensive place to live.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "drainpipe",
    meaning: "排水管",
    example: "Something blocked the drainpipe and the basement flooded.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "drill",
    meaning: "鑽孔機",
    example: "I used a drill to make a hole in the wood.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "dump truck",
    meaning: "傾卸車",
    example: "The dump truck had to make ten trips to haul away all the dirt and gravel.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "elevator",
    meaning: "電梯",
    example: "Take the elevator to the third floor.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "entranceway",
    meaning: "入口",
    example: "The entranceway was lined with photographs of all the family members.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "escalator",
    meaning: "電扶梯",
    example: "You can take the escalator up to the second floor.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "fire escape",
    meaning: "逃生通道",
    example: "The building code states that the door to the fire escape has to be unlocked at all times.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "foreman",
    meaning: "工頭；領班",
    example: "All changes to the plans have to be approved by the construction foreman.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "foundation",
    meaning: "地基",
    example: "A strong foundation is needed to build a good house.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "furniture",
    meaning: "家具",
    example: "The house had furniture in it when we moved in.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "hard hat",
    meaning: "工地安全帽",
    example: "You need to wear a hard hat in the construction site.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "hedge",
    meaning: "樹籬；籬笆",
    example: "John spent the afternoon trimming the hedges in his garden.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "in case of",
    meaning: "萬一",
    example: "In case of fire, pull this lever.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "infrastructure",
    meaning: "基礎建設",
    example: "The Canadian government has spent a lot of money on infrastructure in the last five years.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "intercom",
    meaning: "對講機",
    example: "There is an emergency intercom inside every elevator.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "kitchen sink",
    meaning: "廚房水槽",
    example: "My kitchen sink is clogged.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "ladder",
    meaning: "梯子",
    example: "Doug climbed up the ladder to get onto the roof.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "landlord",
    meaning: "房東",
    example: "My landlord's rules are too strict, so I think I'll move next year.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "landmark",
    meaning: "地標",
    example: "This building has been a landmark in the city for more than 200 years.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "lawn",
    meaning: "草坪；草地",
    example: "You need to mow the lawn; the grass is too long.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "leak",
    meaning: "漏洞；（水、瓦斯等的）漏出；裂縫",
    example: "There must be a leak in the water pipe because the floor in the kitchen is all wet.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "lease",
    meaning: "租用",
    example: "We don't own the building; we lease it.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "lot",
    meaning: "（作特定用處的）一塊地",
    example: "My company is looking for a lot on which to build a factory.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "made to order",
    meaning: "訂做的",
    example: "The window was made to order.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "marble",
    meaning: "大理石",
    example: "The floors in my new apartment are made of marble.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "mezzanine",
    meaning: "夾樓；中層樓",
    example: "From the mezzanine, I had a nice view of the entire hotel lobby.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "mortgage",
    meaning: "房屋貸款；抵押；抵押單據",
    example: "Rick has a twenty-year mortgage.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "move in",
    meaning: "搬進",
    example: "The owners said that we could move in anytime after March 1st.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "nail",
    meaning: "釘子",
    example: "The entire log house was built without using a single nail.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "neighborhood",
    meaning: "鄰近地區",
    example: "My neighborhood in New York is famous for its museums and interesting cafes.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "nightstand",
    meaning: "床頭几",
    example: "I usually keep an alarm clock and a small light on the nightstand.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "nursery",
    meaning: "育嬰室",
    example: "It's a good idea to have the nursery right beside the master bedroom.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "paint",
    meaning: "油漆；塗以顏色；畫",
    example: "I had to go to three stores to find paint that matched my living room walls.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "pantry",
    meaning: "餐具室；食品儲藏室",
    example: "There is often a pantry next to the kitchen in old farmhouses.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "permanent",
    meaning: "長久的；永久的",
    example: "Please write down a permanent address so we can reach you in the future.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "plumber",
    meaning: "水管工",
    example: "The plumber told us that we had to replace some of the old pipes.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "porch",
    meaning: "陽臺；走廊；門廊",
    example: "My grandmother loves to sit on the porch and drink tea in the afternoon.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "property",
    meaning: "房產；地產；所有權",
    example: "My grandfather left me some property in the farming area outside Boston.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "real estate",
    meaning: "房地產；不動產",
    example: "Real estate prices have increased this year.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "refrigerator",
    meaning: "冰箱",
    example: "The kitchen has space for a large refrigerator next to the sink.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "regional",
    meaning: "地區的；區域性的",
    example: "There is a regional law that doesn't allow farmland to be converted to housing districts.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "remodel",
    meaning: "改建；重新塑造",
    example: "Many people remodel their kitchens to raise the value of the house before selling it.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "renovation",
    meaning: "整修",
    example: "Please give me an estimate on the renovation of this building.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "rent",
    meaning: "租金；出租的財產；租用",
    example: "When is the rent due each month?",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "residence",
    meaning: "住所；住宅；居住",
    example: "Many movie stars keep a residence in several different countries.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "sandpaper",
    meaning: "砂紙",
    example: "The builders used sandpaper to remove the rough edges on the wood.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "shovel",
    meaning: "鏟子；鐵鍬；鏟",
    example: "To dig a hole that size with shovels would take several hours.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "soil",
    meaning: "泥土；弄髒",
    example: "We bought some special soil for our garden.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "spacious",
    meaning: "寬敞的",
    example: "Rick rents a spacious studio apartment.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "sprinkler",
    meaning: "灑水車；灑水器",
    example: "The sprinkler was set off when a fire started in the storeroom.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "square foot",
    meaning: "平方英尺",
    example: "The room was twenty square feet.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "stairs",
    meaning: "樓梯",
    example: "Can you give me a hand getting this air-conditioning unit up the stairs?",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "story",
    meaning: "（建築物的）層；樓",
    example: "The building is 101 stories high.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "sublet",
    meaning: "轉租；分租",
    example: "My apartment lease has a provision that allows me to sublet if I want to.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "suburb",
    meaning: "（城市周圍的）郊區",
    example: "It's cheaper to live in a suburb, but it's more convenient to live downtown.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "tape measure",
    meaning: "捲尺",
    example: "I need a tape measure to see how long the sofa is.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "tenant",
    meaning: "房客；承租人",
    example: "The previous tenant moved out without paying the rent.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "territory",
    meaning: "領土；版圖",
    example: "There is a lot of wild and empty territory in the middle of Australia.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "tidy",
    meaning: "整齊的",
    example: "Sophie always keeps her room very tidy.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "tile",
    meaning: "磁磚",
    example: "Some houses have floors made of wood, while others have floors covered with tiles or carpet.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "timber",
    meaning: "木材；木料",
    example: "My family made its money from buying forested land and then selling the timber.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "utility",
    meaning: "公用事業",
    example: "The rent is eight hundred dollars a month plus utilities.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "wallpaper",
    meaning: "壁紙",
    example: "The first thing I do when I move into a new apartment is put up new wallpaper.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "wheelbarrow",
    meaning: "手推車；獨輪小車",
    example: "We had to use a wheelbarrow to bring the bricks into the backyard.",
    category: "房屋地產",
    importance: 3
  },
  {
    text: "advanced",
    meaning: "先進的；進階的",
    example: "The station has a very advanced computer system that tells you where all the trains are.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "adventure",
    meaning: "冒險；冒險精神",
    example: "It was supposed to be a simple bus trip, but it turned into a real adventure.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "agent",
    meaning: "經紀人；代理人",
    example: "The travel agent says we can pay for the tickets with a credit card.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "aircraft",
    meaning: "飛機；航空器",
    example: "The new Airbus is the largest aircraft in the world.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "airline",
    meaning: "航空公司",
    example: "Airlines have been hit hard by the recent increase in oil prices.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "announcement",
    meaning: "公告；宣告",
    example: "I just heard an announcement that the train is going to be late.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "assist",
    meaning: "協助；幫助",
    example: "Can you assist Carol with the scheduling?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "available",
    meaning: "可取得的；有空的",
    example: "The hotel does not have any single rooms available.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "bed and breakfast",
    meaning: "提供住宿加早餐的旅館或民宿",
    example: "Many people prefer to stay at a bed and breakfast when they visit wine country.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "bellhop",
    meaning: "行李員；侍者",
    example: "I prefer to carry my own bags so I don't have to tip the bellhop.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "belongings",
    meaning: "財產；攜帶物品",
    example: "Please remember to take all of your personal belongings with you.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "beverage",
    meaning: "飲料",
    example: "What kind of beverages do you offer?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "blanket",
    meaning: "毯子；毛毯",
    example: "Can you ask the flight attendant to give me a blanket?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "blizzard",
    meaning: "暴風雪",
    example: "My flight was cancelled because of the blizzard.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "board",
    meaning: "登上（車、船、飛機等）",
    example: "We need to board the plane now, as it will be leaving soon.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "boarding gate",
    meaning: "登機門",
    example: "How do I get to the boarding gate?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "boarding pass",
    meaning: "登機證",
    example: "You need a boarding pass to get on a plane.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "book",
    meaning: "預訂；預約",
    example: "I'd like to book a flight for sometime next week.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "breeze",
    meaning: "微風",
    example: "Let's take a walk and enjoy the breeze on the beach.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "bus stop",
    meaning: "公車停靠站",
    example: "There is a convenient bus stop located right outside my hotel.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "business center",
    meaning: "商務中心",
    example: "The business center was recently outfitted with six brand new computers.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "bustling",
    meaning: "（交通）繁忙的；熙攘的",
    example: "I made a reservation at a hotel in a bustling part of the city.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "cabin",
    meaning: "機艙",
    example: "Smoking is not allowed in the cabin.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "captain",
    meaning: "機長；船長",
    example: "The captain announced that we would be landing shortly.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "carry-on",
    meaning: "（帶進機艙的）隨身行李",
    example: "Do you have any carry-on luggage?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "casino",
    meaning: "賭場",
    example: "Most of the hotels in Las Vegas double as casinos.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "check in",
    meaning: "報到；登記入住（旅館）",
    example: "You need to check in first, or you won't be able to get on the plane.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "chilly",
    meaning: "冷的",
    example: "It usually gets chilly at night.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "claim",
    meaning: "要求～的所有權；認領；宣稱",
    example: "You must show your ticket before you can claim your baggage.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "coincide",
    meaning: "同時發生；（想法、意見等）一致",
    example: "Our trip coincides with the festival.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "compact",
    meaning: "小型轎車",
    example: "I had to rent a full-size car because all the compacts were taken.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "complimentary",
    meaning: "【美】贈送的",
    example: "We offer a complimentary breakfast on the first floor.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "concierge",
    meaning: "服務台職員",
    example: "The concierge told us about a great seafood restaurant right on the beach.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "conductor",
    meaning: "（火車的）隨車服務員；（電車、巴士的）車掌",
    example: "Next time the conductor walks by, ask him if there is any wireless Internet on this train.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "confirm",
    meaning: "確認；確定；證實",
    example: "I'm just calling to confirm that our seats have been booked.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "confusion",
    meaning: "困惑；混亂",
    example: "The city was in a state of confusion after the earthquake.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "connecting flight",
    meaning: "轉機",
    example: "My plane landed at six, so I had lots of time to get to my connecting flight.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "contact",
    meaning: "聯繫；接觸",
    example: "You need to contact the hotel and let them know we'll be late.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "continental breakfast",
    meaning: "歐陸式早餐",
    example: "I'm never that hungry in the morning, so I usually order the continental breakfast.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "cottage",
    meaning: "度假小屋；農舍",
    example: "The hotel had sixty rooms plus ten nice cottages down by the lake.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "crew",
    meaning: "（飛機的）全體機員；空勤人員",
    example: "The entire flight crew changed during the stopover in Tokyo.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "cruise",
    meaning: "航遊",
    example: "I'd like to try cruise travel next year.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "cruising altitude",
    meaning: "飛行高度",
    example: "This is your captain speaking. Our current cruising altitude is 30,000 feet.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "curve",
    meaning: "（道路的）彎曲處",
    example: "The car went around the curve too fast.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "customs",
    meaning: "海關",
    example: "How long does it take to go through customs?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "customs declaration (form)",
    meaning: "海關申報表",
    example: "Please fill out the customs declaration form and sign it at the bottom.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "deal with",
    meaning: "處理；應付",
    example: "I prefer to go on organized tours so I don't have to deal with the planning.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "deck",
    meaning: "（船的）艙面；甲板",
    example: "Passengers are not allowed out on deck while the ferry is docking.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "delay",
    meaning: "使延後；延遲",
    example: "The flight has been delayed until three o'clock.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "deluxe",
    meaning: "豪華的；奢侈的",
    example: "We bought tickets for the deluxe train car.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "depart",
    meaning: "啟程；出發",
    example: "The train will depart at six o'clock, so don't be late.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "destination",
    meaning: "目的地；終點",
    example: "We're going to Paris, but on this ticket it says the destination is London!",
    category: "旅遊",
    importance: 3
  },
  {
    text: "destructive",
    meaning: "破壞的；毀滅性的",
    example: "Although the typhoon was very powerful, it was not very destructive.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "disappoint",
    meaning: "使失望；使挫折",
    example: "I'm sorry to disappoint you, but the train is not going to arrive on time.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "dock",
    meaning: "（停靠）碼頭",
    example: "This ship docked in New York at seven in the morning.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "drop-off service",
    meaning: "異地還車服務",
    example: "Do you offer a drop-off service?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "duration",
    meaning: "（某事物持續進行或存在的）一段期間",
    example: "I spent the duration of my vacation relaxing on the beach.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "duty-free shop",
    meaning: "免稅商店",
    example: "Duty-free shops tend to sell luxury items, such as expensive whiskey and perfume.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "economize",
    meaning: "節約；節省",
    example: "We can economize by taking the train instead of flying.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "economy class",
    meaning: "經濟艙",
    example: "The seats in economy class have gotten smaller and smaller in recent years.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "embarkation",
    meaning: "搭乘；從事",
    example: "At embarkation, please have your passport available.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "equivalent",
    meaning: "相同的；等值的；同意義的",
    example: "US$500 is equivalent to about NT$16,000.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "excursion",
    meaning: "短程旅行；遠足",
    example: "We're going on an excursion to Ilan next weekend.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "expense",
    meaning: "費用；開支",
    example: "Plane tickets are usually the biggest expense of a trip overseas.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "expire",
    meaning: "到期；期滿",
    example: "We can't issue you a visa because your passport has expired.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "extend",
    meaning: "延長；擴大；延伸",
    example: "We want to extend our trip by two days.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "fare",
    meaning: "（公車、飛機、計程車等）費用",
    example: "How much is the bus fare from the station to the zoo?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "fill up",
    meaning: "（汽油）加滿",
    example: "Do I have to fill up the gas tank when I return the car?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "final call",
    meaning: "最後登機廣播",
    example: "This is the final call for flight 209 to Boston.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "fine",
    meaning: "罰金",
    example: "Anyone caught smoking in the lavatory will receive a large fine.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "fog",
    meaning: "霧；霧氣",
    example: "The airport is closed due to fog about four times a year.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "freezing",
    meaning: "冰凍的",
    example: "It's freezing outside. We should stay in the hotel.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "front desk",
    meaning: "櫃檯",
    example: "Call the front desk and see when the next airport shuttle bus is leaving.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "gangway",
    meaning: "舷梯；舷門；跳板",
    example: "We had to wait for a few minutes as the gangway was attached to the aircraft.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "hostel",
    meaning: "青年旅舍",
    example: "The youth hostel was cheaper than the motel.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "housekeeping (service)",
    meaning: "房間清潔（服務）",
    example: "Every time I get in the shower, housekeeping shows up and wants to clean the room.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "inn",
    meaning: "小旅館；小飯店；小酒館",
    example: "My wife and I stayed at a lovely country inn to celebrate our anniversary.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "intend",
    meaning: "打算；計畫",
    example: "We intend to do lots of shopping on this trip!",
    category: "旅遊",
    importance: 3
  },
  {
    text: "issue",
    meaning: "核發；發行",
    example: "Where was your passport issued?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "itinerary",
    meaning: "旅行計畫；行程；路線",
    example: "According to the itinerary, we'll be going to see a show tomorrow night.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "jet lag",
    meaning: "時差",
    example: "It usually takes me about thirty-six hours to recover from jet lag.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "keycard",
    meaning: "房卡；鑰匙卡",
    example: "I thought they gave me the wrong keycard, but I was just putting it in the wrong way.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "landing",
    meaning: "降落；登陸",
    example: "It was such a smooth landing that I couldn't even tell when the wheels touched the ground.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "laundry service",
    meaning: "衣物清洗服務",
    example: "The laundry service here is fast and convenient, but it sure is expensive!",
    category: "旅遊",
    importance: 3
  },
  {
    text: "leave for",
    meaning: "動身前往（某處）",
    example: "We have reservations for flight number 109 leaving tomorrow morning at 9:15 for Paris.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "license",
    meaning: "許可證；執照；牌照",
    example: "You need a valid license to rent this car.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "lodge",
    meaning: "休閒遊樂區的旅館；山林小屋",
    example: "My family reserves the same ski lodge every year for our winter vacation.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "luggage cart",
    meaning: "行李推車",
    example: "My suitcase has wheels on the bottom, so I don't need a luggage cart.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "maid",
    meaning: "女僕",
    example: "The maid who cleaned my room did an excellent job.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "metal detector",
    meaning: "金屬探測器",
    example: "I had to go through two metal detectors just to get inside the airport.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "metropolitan",
    meaning: "大都市的",
    example: "The subway system goes all around the metropolitan area.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "mileage",
    meaning: "總英里數；（平均每單位燃料的）行駛里數",
    example: "Is there a mileage limit?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "multiple",
    meaning: "眾多的；多樣的",
    example: "This train ticket allows me to make multiple stops.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "nervously",
    meaning: "緊張地",
    example: "She's scared of flying and is nervously looking out the window.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "nonstop flight",
    meaning: "直達航班",
    example: "Korean Air has a new nonstop flight from Seoul to New York.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "not to mention",
    meaning: "更別說",
    example: "The hotel has a five-star spa, not to mention a swimming pool.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "one-way ticket",
    meaning: "單程票",
    example: "Round-trip tickets are often cheaper than two one-way tickets combined.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "optional",
    meaning: "可選擇的；非必須的",
    example: "You don't have to go shopping with everyone else; it's optional.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "overhead compartment",
    meaning: "（機艙上方的）置物櫃",
    example: "Could you help me put this bag in the overhead compartment?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "overlook",
    meaning: "眺望；俯瞰",
    example: "The fancy restaurant is located on a hill, overlooking the city.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "parking meter",
    meaning: "停車計時器",
    example: "Do you have any coins for the parking meter?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "passenger",
    meaning: "乘客；旅客",
    example: "One of the passengers on the flight had a heart attack, and we had to land.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "port",
    meaning: "港口",
    example: "The main ferry port in Vancouver is located quite far from downtown.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "preclude",
    meaning: "阻止；妨礙",
    example: "Rain would preclude our plans to have a picnic.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "preferably",
    meaning: "寧可；偏好",
    example: "I'd like to reserve a suite, preferably one with a jacuzzi.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "prohibit",
    meaning: "（以權力）禁止；阻止",
    example: "Smoking is prohibited on the train.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "punctually",
    meaning: "準時地",
    example: "The trains always leave punctually; they're never late.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "railway",
    meaning: "鐵路",
    example: "You can buy your ticket at the railway station.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "ramp",
    meaning: "空橋；（上下飛機用的）活動舷梯",
    example: "Take the second ramp on the left to get to the parking level.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "rate",
    meaning: "費率；速度；比率",
    example: "Does the taxi rate go up during holidays?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "refreshment",
    meaning: "茶點；便餐",
    example: "The flight was quite short, so no refreshments were served.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "relatively",
    meaning: "相對地；比較上；相當",
    example: "A plane ticket is relatively expensive, but we'll get there faster.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "remote",
    meaning: "偏僻的；遙遠的；遙控的",
    example: "You don't see many people at this station because it's so remote.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "renew",
    meaning: "使更新；重新開始",
    example: "You'd better renew your passport before your current one runs out.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "reservation",
    meaning: "預約；保留",
    example: "You have a reservation for two tickets to Tokyo.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "resort",
    meaning: "度假飯店",
    example: "Paradise Grove is the most expensive resort on the island.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "route map",
    meaning: "路線圖",
    example: "You can pick up a detailed route map at the tourist office in the lobby.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "rush hour",
    meaning: "（交通）尖峰時間",
    example: "Let's wait until after rush hour before we go out for dinner.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "security checkpoint",
    meaning: "安全檢查站",
    example: "You will have to take your laptop out of your bag at the security checkpoint.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "security guard",
    meaning: "保全人員",
    example: "There are two security guards in the lobby.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "set off",
    meaning: "出發；動身",
    example: "They set off for Paris this early morning.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "shuttle service",
    meaning: "接送服務",
    example: "Do you have an airport shuttle service?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "sightseeing brochure",
    meaning: "旅遊手冊",
    example: "The sightseeing brochure had a detailed map of the entire downtown area.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "sign up",
    meaning: "報名",
    example: "Many business people sign up for frequent flyer mileage.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "standby",
    meaning: "候補",
    example: "What are the chances of flying standby to Chicago on the next flight?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "substantially",
    meaning: "遠遠地；大大地；實質上；大體上",
    example: "Planes are substantially faster than other kinds of transport.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "subway",
    meaning: "地下鐵",
    example: "The city plans to extend the subway to the airport by the end of next year.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "suite",
    meaning: "套房",
    example: "All of our suites have full kitchens and two bathrooms.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "sunscreen lotion",
    meaning: "防曬油",
    example: "It is very sunny outside, so put some sunscreen lotion on to protect your skin.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "system",
    meaning: "系統；制度；方法",
    example: "The station has a very good system for making sure the trains leave on time.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "take off",
    meaning: "（飛機）起飛；休假",
    example: "The plane finally took off after a delay of over an hour.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "taxi stand",
    meaning: "計程車招呼站",
    example: "Over fifteen taxis were lined up at the taxi stand waiting for customers.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "terminal",
    meaning: "機場航廈；（火車、巴士等的）終站",
    example: "All domestic flights arrive and depart from terminal two.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "thrill",
    meaning: "興奮感；使人興奮的事物",
    example: "Flying is always a thrill for me.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "ticket",
    meaning: "票；券",
    example: "How much is a ticket to Hong Kong?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "timetable",
    meaning: "火車時刻表",
    example: "Where can I get a copy of the timetable?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "tour guide",
    meaning: "導遊",
    example: "The tour guide led the tourists around the famous park.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "tourist information",
    meaning: "觀光資訊",
    example: "There is a tourist information booth at the far end of the terminal.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "trolley",
    meaning: "【美】有軌電車",
    example: "Every tourist that comes to San Francisco wants to ride on the trolley at least once.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "tropical",
    meaning: "熱帶的",
    example: "The resort is located on a tropical island, so be prepared for some hot weather.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "trunk",
    meaning: "（汽車）後車廂",
    example: "When the taxi dropped me off, I completely forgot about my suitcase in the trunk.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "turbulence",
    meaning: "亂流",
    example: "We expect some turbulence ahead, so please fasten your seat belt.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "urgent",
    meaning: "緊急的；急迫的",
    example: "There is an urgent telephone call for Mr. Blake.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "vacancy",
    meaning: "空房；空缺",
    example: "Weekends are busy, but we always have vacancies during the week.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "valet",
    meaning: "代客泊車服務員",
    example: "I'm always a little bit nervous when I give my car keys to the valet.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "valid",
    meaning: "有效的；有根據的",
    example: "You need a valid passport to travel abroad.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "vehicle",
    meaning: "車輛",
    example: "What kind of vehicles do you have?",
    category: "旅遊",
    importance: 3
  },
  {
    text: "villa",
    meaning: "度假別墅",
    example: "My company rented a villa for the executives visiting from Japan.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "wake-up call",
    meaning: "喚醒服務",
    example: "I'll need a wake-up call at 6:30.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "windshield",
    meaning: "（汽車的）擋風玻璃",
    example: "It was raining so hard that I could barely see through the windshield.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "zone",
    meaning: "地帶；地區",
    example: "You got a ticket because you were in an illegal parking zone.",
    category: "旅遊",
    importance: 3
  },
  {
    text: "alcohol",
    meaning: "酒精；含酒精的飲料",
    example: "Whiskey has a lot more alcohol than wine or beer.",
    category: "外食",
    importance: 3
  },
  {
    text: "annual",
    meaning: "一年一度的",
    example: "Mr. Paul Newton will be the keynote speaker at our annual conference.",
    category: "外食",
    importance: 3
  },
  {
    text: "appeal",
    meaning: "對（某人）有吸引力；呼籲；懇請",
    example: "This restaurant appeals to people with lots of money to spend.",
    category: "外食",
    importance: 3
  },
  {
    text: "appetite",
    meaning: "食慾",
    example: "I hope you have a good appetite.",
    category: "外食",
    importance: 3
  },
  {
    text: "arrive",
    meaning: "到達；送達",
    example: "The guests have started to arrive.",
    category: "外食",
    importance: 3
  },
  {
    text: "atmosphere",
    meaning: "氣氛",
    example: "The music in that restaurant provides great atmosphere.",
    category: "外食",
    importance: 3
  },
  {
    text: "banquet",
    meaning: "宴會",
    example: "The wedding banquet was held in a big room at the Grand Hotel.",
    category: "外食",
    importance: 3
  },
  {
    text: "bartender",
    meaning: "酒吧的侍者；酒保",
    example: "Jenny waved her hand to get the bartender's attention.",
    category: "外食",
    importance: 3
  },
  {
    text: "basic",
    meaning: "簡單的；基本的",
    example: "I just want something basic, like a sandwich or noodles.",
    category: "外食",
    importance: 3
  },
  {
    text: "be accustomed to",
    meaning: "習慣於；適應～",
    example: "Mr. Derek is accustomed to these very formal events.",
    category: "外食",
    importance: 3
  },
  {
    text: "bistro",
    meaning: "小酒館；小飯館",
    example: "One of New York's most famous bistros is just down the street from my office.",
    category: "外食",
    importance: 3
  },
  {
    text: "blend",
    meaning: "混合",
    example: "This drink is made from a blend of coffee beans and chocolate.",
    category: "外食",
    importance: 3
  },
  {
    text: "bring together",
    meaning: "使聚集",
    example: "All her old colleagues were brought together for her retirement party.",
    category: "外食",
    importance: 3
  },
  {
    text: "buffet",
    meaning: "自助餐；吃到飽餐廳",
    example: "I always eat at a buffet on my birthday.",
    category: "外食",
    importance: 3
  },
  {
    text: "caffeine",
    meaning: "咖啡因",
    example: "My doctor told me that tea has just as much caffeine as coffee.",
    category: "外食",
    importance: 3
  },
  {
    text: "cater",
    meaning: "提供飲食；承辦宴席",
    example: "The party was catered by my aunt's catering company.",
    category: "外食",
    importance: 3
  },
  {
    text: "celebration",
    meaning: "慶祝",
    example: "It was the largest July 4th celebration in the city's history.",
    category: "外食",
    importance: 3
  },
  {
    text: "champagne",
    meaning: "香檳",
    example: "It's a tradition to drink champagne on New Year's Eve.",
    category: "外食",
    importance: 3
  },
  {
    text: "charter",
    meaning: "租；包租",
    example: "The company chartered a bus for the trip.",
    category: "外食",
    importance: 3
  },
  {
    text: "checkout counter",
    meaning: "收銀台",
    example: "Fifteen people were waiting in a long line at the checkout counter.",
    category: "外食",
    importance: 3
  },
  {
    text: "chef",
    meaning: "主廚；廚師",
    example: "My aunt is a professional chef.",
    category: "外食",
    importance: 3
  },
  {
    text: "cocktail",
    meaning: "（西餐的）開胃品；水果雜拌；調酒",
    example: "Can I get you a cocktail from the bar?",
    category: "外食",
    importance: 3
  },
  {
    text: "commonly",
    meaning: "一般地；通常地；普通地",
    example: "Our shareholder meetings are commonly held in hotels.",
    category: "外食",
    importance: 3
  },
  {
    text: "complete",
    meaning: "完全的；十足的；完整的",
    example: "The event was a complete success.",
    category: "外食",
    importance: 3
  },
  {
    text: "coordinate",
    meaning: "協調；調整",
    example: "For the event to be successful, we need to coordinate everything with the caterers.",
    category: "外食",
    importance: 3
  },
  {
    text: "cuisine",
    meaning: "菜餚",
    example: "India is famous for its hot and spicy cuisine.",
    category: "外食",
    importance: 3
  },
  {
    text: "culinary",
    meaning: "烹飪的",
    example: "The banquet was a culinary success; everyone thought the food was amazing.",
    category: "外食",
    importance: 3
  },
  {
    text: "daringly",
    meaning: "大膽地；勇敢地",
    example: "She daringly invited the mayor to the party.",
    category: "外食",
    importance: 3
  },
  {
    text: "decaf",
    meaning: "無咖啡因咖啡",
    example: "Are you sure this coffee is decaf?",
    category: "外食",
    importance: 3
  },
  {
    text: "delicious",
    meaning: "美味的",
    example: "The appetizers were tasty and the main course was delicious!",
    category: "外食",
    importance: 3
  },
  {
    text: "demand",
    meaning: "要求；請求",
    example: "But we booked the table a week ago! I demand to see the manager.",
    category: "外食",
    importance: 3
  },
  {
    text: "dessert",
    meaning: "甜點；點心",
    example: "Could we see the dessert menu, please?",
    category: "外食",
    importance: 3
  },
  {
    text: "diet",
    meaning: "飲食；食物",
    example: "Todd has been living on a diet of spaghetti and pizza for months.",
    category: "外食",
    importance: 3
  },
  {
    text: "dietary",
    meaning: "（有關）飲食的",
    example: "Do you have any dietary restrictions?",
    category: "外食",
    importance: 3
  },
  {
    text: "dining",
    meaning: "進餐",
    example: "The dining room was very large and had a wonderful view of the river.",
    category: "外食",
    importance: 3
  },
  {
    text: "dish",
    meaning: "一道菜",
    example: "The chef can easily make many delicious dishes.",
    category: "外食",
    importance: 3
  },
  {
    text: "distinguish",
    meaning: "區別；識別",
    example: "He can distinguish where a wine was produced just by tasting it.",
    category: "外食",
    importance: 3
  },
  {
    text: "dressing",
    meaning: "（拌沙拉等用的）調料",
    example: "I know how to make a simple dressing out of oil and vinegar.",
    category: "外食",
    importance: 3
  },
  {
    text: "drunk",
    meaning: "酒醉的",
    example: "John's friends drove him home because he was too drunk to drive.",
    category: "外食",
    importance: 3
  },
  {
    text: "elegance",
    meaning: "優雅；優美",
    example: "I love the elegance of a five-star hotel.",
    category: "外食",
    importance: 3
  },
  {
    text: "familiar",
    meaning: "熟悉的；常見的",
    example: "Are you familiar with this cafe?",
    category: "外食",
    importance: 3
  },
  {
    text: "feast",
    meaning: "盛宴；（感官等方面的）享受",
    example: "The meal was a feast for the eyes and the stomach!",
    category: "外食",
    importance: 3
  },
  {
    text: "flavor",
    meaning: "口味；味道；香料；調味料",
    example: "What flavor of ice cream would you like?",
    category: "外食",
    importance: 3
  },
  {
    text: "forget",
    meaning: "忘記",
    example: "Did you forget to make a reservation?",
    category: "外食",
    importance: 3
  },
  {
    text: "general",
    meaning: "一般的；公眾的；大體的",
    example: "There was general agreement that this was the best party of the year.",
    category: "外食",
    importance: 3
  },
  {
    text: "go Dutch",
    meaning: "各自付帳；平攤費用",
    example: "Let's go Dutch, OK?",
    category: "外食",
    importance: 3
  },
  {
    text: "gourmet",
    meaning: "美食家",
    example: "My friend Jenny is a true gourmet and won't eat fast food.",
    category: "外食",
    importance: 3
  },
  {
    text: "grind",
    meaning: "磨碎；碾碎",
    example: "The grocery store has a special machine for grinding the coffee beans.",
    category: "外食",
    importance: 3
  },
  {
    text: "guide",
    meaning: "指導手冊；指南；導遊",
    example: "The restaurant guide gave this place a high rating.",
    category: "外食",
    importance: 3
  },
  {
    text: "hangover",
    meaning: "宿醉",
    example: "In college, Jack often went to class on Monday morning with a hangover.",
    category: "外食",
    importance: 3
  },
  {
    text: "hospitality",
    meaning: "殷勤招待；好客",
    example: "Thank you for the hospitality you have shown me while I've been here.",
    category: "外食",
    importance: 3
  },
  {
    text: "ideally",
    meaning: "理想上",
    example: "Ideally, the banquet should start at 4:00 p.m.",
    category: "外食",
    importance: 3
  },
  {
    text: "impress",
    meaning: "使感動；使留下深刻印象",
    example: "If you want to impress your wedding guests, you should hold an expensive banquet.",
    category: "外食",
    importance: 3
  },
  {
    text: "in honor of",
    meaning: "紀念～；祝賀～；向～致敬",
    example: "The day was declared a holiday in honor of the soldiers who died for their country.",
    category: "外食",
    importance: 3
  },
  {
    text: "incorporate",
    meaning: "納入；使合併；結合",
    example: "It would be great if we could incorporate the presentation into our event.",
    category: "外食",
    importance: 3
  },
  {
    text: "individual",
    meaning: "個別的；個人的；單獨的；特有的",
    example: "The entire staff received individual invitations to the party.",
    category: "外食",
    importance: 3
  },
  {
    text: "ingredient",
    meaning: "成分；原料；因素",
    example: "What are the ingredients of this amazing cake?",
    category: "外食",
    importance: 3
  },
  {
    text: "Keep the change.",
    meaning: "零錢不用找了。",
    example: "Here's thirty dollars. Keep the change.",
    category: "外食",
    importance: 3
  },
  {
    text: "lighting",
    meaning: "燈光",
    example: "We use candles so the lighting is more romantic.",
    category: "外食",
    importance: 3
  },
  {
    text: "list",
    meaning: "名單；列表；清單",
    example: "There are almost a hundred people on our wedding list.",
    category: "外食",
    importance: 3
  },
  {
    text: "luncheon",
    meaning: "（正式的）午餐",
    example: "All the members of the bridal party had a nice luncheon after the rehearsal.",
    category: "外食",
    importance: 3
  },
  {
    text: "main course",
    meaning: "主菜",
    example: "For the main course, we had a choice of steak or lobster.",
    category: "外食",
    importance: 3
  },
  {
    text: "majority",
    meaning: "多數；過半數",
    example: "The majority of the people we invited are going to attend.",
    category: "外食",
    importance: 3
  },
  {
    text: "margarine",
    meaning: "人造奶油",
    example: "Margarine is cheaper than real butter and it tastes almost as good.",
    category: "外食",
    importance: 3
  },
  {
    text: "mayonnaise",
    meaning: "美乃滋",
    example: "I asked them not to put mayonnaise on my sandwich.",
    category: "外食",
    importance: 3
  },
  {
    text: "mix",
    meaning: "（社交場合中的）交際；交往；使混合",
    example: "Parties are a great place for people to mix.",
    category: "外食",
    importance: 3
  },
  {
    text: "mixture",
    meaning: "混合物；混合料",
    example: "Why don't you help put the mixture into a baking pan?",
    category: "外食",
    importance: 3
  },
  {
    text: "mix-up",
    meaning: "混亂的狀態；混合（物）",
    example: "There seems to be a mix-up; you gave us a table near the kitchen, but we wanted a table near the window.",
    category: "外食",
    importance: 3
  },
  {
    text: "muffin",
    meaning: "鬆糕",
    example: "For breakfast, Iris just picks up a coffee and a muffin at the coffee shop.",
    category: "外食",
    importance: 3
  },
  {
    text: "napkin",
    meaning: "餐巾",
    example: "The waitress folded the napkins and put one beside each plate.",
    category: "外食",
    importance: 3
  },
  {
    text: "occasion",
    meaning: "場合；活動",
    example: "The party to celebrate my daughter's birth was a very happy occasion.",
    category: "外食",
    importance: 3
  },
  {
    text: "pancake",
    meaning: "薄煎餅；鬆餅",
    example: "This restaurant serves real maple syrup with its pancakes.",
    category: "外食",
    importance: 3
  },
  {
    text: "pardon",
    meaning: "原諒；寬恕",
    example: "I beg your pardon.",
    category: "外食",
    importance: 3
  },
  {
    text: "patron",
    meaning: "老顧客；常客；贊助者",
    example: "Patrons of the hotel can park their cars for free.",
    category: "外食",
    importance: 3
  },
  {
    text: "pour",
    meaning: "倒；灌",
    example: "Let me pour. Say when.",
    category: "外食",
    importance: 3
  },
  {
    text: "predict",
    meaning: "預測；預言；預告",
    example: "It's difficult to predict how much food you'll need for a banquet.",
    category: "外食",
    importance: 3
  },
  {
    text: "profession",
    meaning: "職業；專業",
    example: "Annie enjoys her profession as a party planner.",
    category: "外食",
    importance: 3
  },
  {
    text: "reception",
    meaning: "招待會；歡迎會；宴會",
    example: "The wedding reception will take place at the Hyatt Hotel.",
    category: "外食",
    importance: 3
  },
  {
    text: "recipe",
    meaning: "烹飪法；食譜",
    example: "My aunt's chocolate cake was delicious, and I asked her for the recipe.",
    category: "外食",
    importance: 3
  },
  {
    text: "relinquish",
    meaning: "讓與；釋放；放棄",
    example: "Andy relinquished his seat to a guest who was waiting.",
    category: "外食",
    importance: 3
  },
  {
    text: "remind",
    meaning: "提醒；使想起",
    example: "The waiter forgot my drink; I need to remind him.",
    category: "外食",
    importance: 3
  },
  {
    text: "saltshaker",
    meaning: "（瓶蓋有細孔的）鹽瓶",
    example: "Could you pass me the saltshaker?",
    category: "外食",
    importance: 3
  },
  {
    text: "seafood",
    meaning: "海鮮",
    example: "The secretary made reservations at a seafood restaurant for her boss.",
    category: "外食",
    importance: 3
  },
  {
    text: "specialty",
    meaning: "特製品；特產；招牌菜",
    example: "This restaurant's specialty is filet mignon with fresh mushrooms.",
    category: "外食",
    importance: 3
  },
  {
    text: "starve",
    meaning: "挨餓；【口】餓得慌",
    example: "I am starving after all this working out. Let's grab a sandwich!",
    category: "外食",
    importance: 3
  },
  {
    text: "stew",
    meaning: "燉煮的食物；燉",
    example: "It's an informal lunch, so they will serve a simple stew plus soup and sandwiches.",
    category: "外食",
    importance: 3
  },
  {
    text: "subject to",
    meaning: "仰賴；取決於",
    example: "Wine quality is subject to the quality of the grapes it is made from.",
    category: "外食",
    importance: 3
  },
  {
    text: "suggestion",
    meaning: "建議；提議；暗示",
    example: "I'll go with your suggestion and have the seafood pizza.",
    category: "外食",
    importance: 3
  },
  {
    text: "tender",
    meaning: "嫩的；柔軟的",
    example: "The steak was so tender that I could use a fork to cut it up and eat it.",
    category: "外食",
    importance: 3
  },
  {
    text: "theme",
    meaning: "主題；主旨",
    example: "This banquet has a Halloween theme, so you should wear a costume.",
    category: "外食",
    importance: 3
  },
  {
    text: "tip",
    meaning: "給小費；小費",
    example: "In America, people always tip the waiter when dining in a restaurant.",
    category: "外食",
    importance: 3
  },
  {
    text: "treat",
    meaning: "請客；款待",
    example: "It's my treat.",
    category: "外食",
    importance: 3
  },
  {
    text: "turnout",
    meaning: "（集會等的）參加或出席人數",
    example: "There was a record turnout at the Las Vegas Expo.",
    category: "外食",
    importance: 3
  },
  {
    text: "utensil",
    meaning: "器皿；用具",
    example: "The restaurant was so busy that they ran out of clean utensils by nine o'clock.",
    category: "外食",
    importance: 3
  },
  {
    text: "vegetable",
    meaning: "蔬菜",
    example: "The New York steak comes with potatoes and your choice of vegetables.",
    category: "外食",
    importance: 3
  },
  {
    text: "vegetarian",
    meaning: "素食主義者（的）；素菜的",
    example: "Sue is a vegetarian. She doesn't eat meat.",
    category: "外食",
    importance: 3
  },
  {
    text: "well-done",
    meaning: "（牛排）八分至全熟的；完全煮熟的",
    example: "I'd like my steak well-done.",
    category: "外食",
    importance: 3
  },
  {
    text: "action",
    meaning: "動作；行動",
    example: "I don't like action movies very much; there's always too much fighting.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "admire",
    meaning: "崇拜；尊敬",
    example: "I really admire this actor because all of his movies are great.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "album",
    meaning: "唱片專輯；相簿；集郵簿",
    example: "Michelle has every album the Rolling Stones ever recorded.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "amplifier",
    meaning: "擴音器",
    example: "Jason plugged his electric guitar into the amplifier and began to play.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "ancient",
    meaning: "古老的",
    example: "I am very interested in the ancient city of Babylon.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "animation",
    meaning: "動畫片",
    example: "Animation used to be aimed mainly at children, but today animation is popular with adults, too.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "antique",
    meaning: "古董",
    example: "Every Sunday, my wife and I drove around the countryside shopping for antiques.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "approach",
    meaning: "方法；通路；接近",
    example: "His approach to art is to paint what he feels, not what he sees.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "artist",
    meaning: "藝術家",
    example: "My best friend is an artist, but he prefers to give away his paintings rather than sell them.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "audience",
    meaning: "（電影、表演、演講等的）觀眾；聽眾",
    example: "The audience enjoyed the play.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "audition",
    meaning: "甄選",
    example: "The life of an actor is all about going to audition after audition.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "ballet",
    meaning: "芭蕾舞",
    example: "For our anniversary, my wife purchased two tickets to the ballet.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "baton",
    meaning: "指揮棒",
    example: "The conductor waved his baton and the orchestra began to play.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "be in the running for",
    meaning: "有獲得～的機會",
    example: "Russia can't win the gold medal anymore, but they are still in the running for the bronze.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "biography",
    meaning: "傳記",
    example: "I used to read novels, but now I find biographies to be much more interesting.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "box office",
    meaning: "票房",
    example: "Critics praised the movie, but it was a failure at the box office.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "broaden",
    meaning: "增廣；擴大",
    example: "Studying art has really broadened my mind.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "canvas",
    meaning: "帆布；油畫布",
    example: "The artist stared at the blank canvas for days as she thought about what to paint.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "carnival",
    meaning: "嘉年華會；狂歡",
    example: "When I was young, a carnival came to my hometown in the fall every year.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "category",
    meaning: "種類",
    example: "His music is so different that it can't be put into just one category.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "cathedral",
    meaning: "大教堂",
    example: "The cathedral's stained glass windows poured colored light over the pews.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "century",
    meaning: "世紀",
    example: "This ancient castle was built in the 17th century.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "chamber music",
    meaning: "室內樂",
    example: "In the past, rich people often had chamber music playing as they dined.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "champion",
    meaning: "冠軍",
    example: "My grandfather was a champion boxer in his youth.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "channel",
    meaning: "頻道",
    example: "The TV programs on channels fifty to sixty are all about science, travel, and animals.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "cinema",
    meaning: "電影院；（一部）電影",
    example: "The new cinema at the mall can show both regular and 3D movies.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "classical",
    meaning: "古典的",
    example: "My grandmother listens to classical music in the evening.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "collection",
    meaning: "收集；收藏",
    example: "I have a collection of nature DVDs.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "combine",
    meaning: "結合；組合",
    example: "His songs combine jazz with classical music.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "compose",
    meaning: "作曲",
    example: "Nowadays, many musicians compose all their music on computers.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "contest",
    meaning: "競賽；比賽",
    example: "The winner of the singing contest was a 12-year-old girl from a nearby small town.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "continue",
    meaning: "繼續；持續",
    example: "The show will continue after the break.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "creative",
    meaning: "有創意的；有想像力的",
    example: "I'm not very creative, so I'm not very good at art.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "criticism",
    meaning: "批評；評論",
    example: "The theater came under criticism for allowing people to smoke.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "debut",
    meaning: "首次露面；初次登臺",
    example: "The debut of the opera was attended by many of the rich and famous.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "dialogue",
    meaning: "對話；對白",
    example: "There wasn't much dialogue in that new kung fu movie.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "disparate",
    meaning: "截然不同的；無共同點的",
    example: "She has taken two disparate music styles and made them work very well together.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "disperse",
    meaning: "（使）散開；（使）分散",
    example: "The crowd began to disperse after the concert.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "disseminate",
    meaning: "散播；宣傳",
    example: "She helped disseminate information about the new artist.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "distinctive",
    meaning: "有特色的；特殊的",
    example: "A distinctive smell wafted out of the restaurant's open windows.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "distraction",
    meaning: "使人分心之物；娛樂消遣",
    example: "I study in the library because there are no distractions.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "documentary",
    meaning: "紀錄片；紀錄片的",
    example: "I saw a fascinating documentary on the life of Napoleon.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "dub",
    meaning: "配音；配入的聲音",
    example: "Pixar did an excellent job of dubbing Miyazaki's movies into English.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "duet",
    meaning: "二重唱",
    example: "The musical ended with a duet by the hero and the heroine.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "element",
    meaning: "要素；元素；成分",
    example: "Loud drums are just one element of the band's style.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "entertainment",
    meaning: "娛樂；消遣",
    example: "Movies are my favorite kind of entertainment.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "episode",
    meaning: "（電視等的）連續劇的一集",
    example: "The final episode of Seinfeld was watched by 76 million people.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "exact",
    meaning: "精確的；絲毫不差的",
    example: "The band played the exact same music as the last time!",
    category: "娛樂",
    importance: 3
  },
  {
    text: "excite",
    meaning: "使興奮；刺激",
    example: "Fireworks always excite a crowd.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "exhibit",
    meaning: "展覽；展示品",
    example: "The museum currently has an exhibit of ancient Japanese weapons.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "express",
    meaning: "表現；表達",
    example: "She used black paint to express her sad feelings.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "fantastic",
    meaning: "極好的",
    example: "The movie got fantastic reviews in the New York Times and in the Washington Post.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "favor",
    meaning: "偏好；贊成；對～有利",
    example: "This artist favors pencils over paint.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "finalist",
    meaning: "決賽選手",
    example: "The five finalists lined up on stage for the judges one last time.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "gallery",
    meaning: "畫廊；美術館",
    example: "The gallery reserved one room for local amateur artists to show their work.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "giveaway",
    meaning: "贈品",
    example: "The store had a giveaway each month to attract more customers.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "habit",
    meaning: "習慣",
    example: "Regularly watching hours of TV is a bad habit.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "hand-made",
    meaning: "手工製的",
    example: "I was very surprised when the owner told me that everything in the store was hand-made.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "historic",
    meaning: "有歷史性的",
    example: "The tour included five historic buildings in the downtown area.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "hit",
    meaning: "成功而風行一時的事物；熱門金曲",
    example: "For his birthday, I got my brother a CD of Tom Petty's greatest hits.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "illustration",
    meaning: "圖解；圖示",
    example: "My favorite dictionary has hundreds of illustrations.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "impact",
    meaning: "衝擊力；影響",
    example: "Her music has had quite an impact on the world.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "in-depth",
    meaning: "深入的；徹底的",
    example: "We shall take an in-depth look at the art of that period.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "influence",
    meaning: "影響",
    example: "He was influenced by Japanese pop music.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "judge",
    meaning: "決定；判斷；斷定",
    example: "It's difficult to judge what kind of music to play at these events.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "league",
    meaning: "聯盟",
    example: "My brother's soccer team is the worst team in the league.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "leisure",
    meaning: "空閒的；閒暇的",
    example: "One of my favorite leisure activities is watching movies.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "literature",
    meaning: "文學作品",
    example: "I love literature, but I have less and less time to read.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "musician",
    meaning: "音樂家",
    example: "It's astonishing how many people living in the Quebec countryside are artists and musicians.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "opera",
    meaning: "歌劇",
    example: "Going to the opera is a great night out, but I hate getting all dressed up.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "orchestra",
    meaning: "管弦樂隊；（劇場中的）樂隊席",
    example: "The orchestra was hidden in a large sunken area in front of the stage.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "painting",
    meaning: "繪畫",
    example: "The painting by Picaso sold for $300,000 at the auction.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "perform",
    meaning: "演出；表演；執行；做",
    example: "The actors performed really well.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "philharmonic",
    meaning: "愛好音樂的；愛樂團體（的）",
    example: "Tonight's concert is the New York Philharmonic Orchestra's final performance of the season.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "prefer",
    meaning: "比較喜歡；偏好",
    example: "What style of art do you prefer?",
    category: "娛樂",
    importance: 3
  },
  {
    text: "premiere",
    meaning: "首映會；初次上演",
    example: "All of the actors and the director walked up the red carpet at the movie's premiere.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "range",
    meaning: "現蓋；範圍涉及～",
    example: "Her songs range from sad love songs to loud rock.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "rehearse",
    meaning: "（戲劇、音樂會等的）排練；排演；演練",
    example: "We need to rehearse more because we still haven't got it quite right.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "relaxation",
    meaning: "娛樂；消遣；放鬆",
    example: "For relaxation, I listen to classical music.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "release",
    meaning: "發行（電影、唱片等）；發布；釋放",
    example: "When will the movie be released in Taiwan?",
    category: "娛樂",
    importance: 3
  },
  {
    text: "representation",
    meaning: "描繪；表述；象徵；代理",
    example: "The painting is a representation of the artist's hometown.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "review",
    meaning: "評論",
    example: "The review praised the acting but said the plot was ridiculous and that the movie was far too long.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "schedule",
    meaning: "排定；安排",
    example: "The play is scheduled to begin next Friday.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "sculpture",
    meaning: "雕塑品",
    example: "A large sculpture of a wounded soldier dominated the main room at the gallery.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "sellout",
    meaning: "售完；（表演、球賽等）大爆滿",
    example: "The popular singer's concerts were all sellouts.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "series",
    meaning: "連續；系列",
    example: "The TV series Cougar Town was cancelled after only one season because of poor ratings.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "significant",
    meaning: "重要的；重大的",
    example: "The musician has had a significant impact on jazz music.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "single",
    meaning: "單曲；獨唱（或獨奏）者",
    example: "The newest single by Madonna was playing on every radio station in the country.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "sitcom",
    meaning: "情境喜劇",
    example: "It's difficult for an actor to make the jump from acting in sitcoms to acting in movies.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "solo",
    meaning: "獨奏；獨唱",
    example: "The drum solo went on and on and the people in front of the stage danced wildly.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "soundtrack",
    meaning: "原聲帶；電影配音",
    example: "I loved the music in the movie, so I'm going to buy the soundtrack.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "spectacular",
    meaning: "引人注目的；驚人的",
    example: "The art gallery is exhibiting a spectacular collection of paintings.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "spectrum",
    meaning: "範圍；幅度；光譜",
    example: "He can play a broad spectrum of musical instruments.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "sponsor",
    meaning: "贊助；贊助者",
    example: "Pepsi will team up with Nokia to sponsor the concert.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "stage",
    meaning: "舞台；高台",
    example: "The singer will be on stage soon.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "stay tuned",
    meaning: "請繼續收看（或收聽）；靜待後續消息",
    example: "That's the end of our show, but stay tuned for more exciting programs.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "subscribe",
    meaning: "訂閱；同意、支持（觀點、想法等）",
    example: "It doesn't cost anything to subscribe to our newsletter online.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "subtitle",
    meaning: "字幕；副標題",
    example: "Do you know how to turn the subtitles off on the DVD?",
    category: "娛樂",
    importance: 3
  },
  {
    text: "successive",
    meaning: "連續的；後繼的",
    example: "This Christmas play has been shown here for four successive years.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "talent",
    meaning: "天賦",
    example: "Parents should encourage their children if they show any talent in art or music.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "taste",
    meaning: "品味；喜好；味道",
    example: "Her taste in music is very strange.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "thriller",
    meaning: "驚悚片",
    example: "The movie is supposed to be a thriller, but I didn't think it was suspenseful at all.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "traditional",
    meaning: "傳統的",
    example: "I enjoy traditional Indian movies with lots of singing and dancing.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "trailer",
    meaning: "（電影的）預告片",
    example: "I really enjoy watching the trailers before the movie begins.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "urge",
    meaning: "鼓勵；催促；力勸",
    example: "I would urge everyone to just pick up a pencil and draw; it's very relaxing.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "vocal",
    meaning: "聲樂作品；聲樂節目",
    example: "I particularly like the music of Fleetwood Mac because of the vocals.",
    category: "娛樂",
    importance: 3
  },
  {
    text: "allow",
    meaning: "准許；允許",
    example: "They don't allow you to smoke in the hospital.",
    category: "保健",
    importance: 3
  },
  {
    text: "alternative",
    meaning: "選擇；選擇的餘地；供選擇的東西",
    example: "I don't want to go to the hospital. Are there any alternatives?",
    category: "保健",
    importance: 3
  },
  {
    text: "antibiotic",
    meaning: "抗生素；抗菌的",
    example: "My doctor gave me some antibiotics to treat the infection on my foot.",
    category: "保健",
    importance: 3
  },
  {
    text: "appointment",
    meaning: "約定；約會；任命",
    example: "I have an appointment to see Dr. Jones at three o'clock.",
    category: "保健",
    importance: 3
  },
  {
    text: "aspect",
    meaning: "方面；角度",
    example: "Seeing a doctor when you are sick is just one aspect of staying healthy.",
    category: "保健",
    importance: 3
  },
  {
    text: "aspirin",
    meaning: "阿斯匹靈",
    example: "Just one tablet of aspirin can make you feel better.",
    category: "保健",
    importance: 3
  },
  {
    text: "assess",
    meaning: "評估；評定",
    example: "The doctor can assess your problem and tell you how best to cure it.",
    category: "保健",
    importance: 3
  },
  {
    text: "aware",
    meaning: "知道的；瞭解的",
    example: "I wasn't aware that my medical insurance didn't cover dental work.",
    category: "保健",
    importance: 3
  },
  {
    text: "bandage",
    meaning: "繃帶",
    example: "Make sure that you change the bandage every couple of days.",
    category: "保健",
    importance: 3
  },
  {
    text: "belly",
    meaning: "腹部；肚子",
    example: "The woman felt a sharp pain in her belly after eating at a seafood restaurant.",
    category: "保健",
    importance: 3
  },
  {
    text: "bruise",
    meaning: "瘀青",
    example: "The child had a large bruise on her back from when she fell off the swings.",
    category: "保健",
    importance: 3
  },
  {
    text: "bump",
    meaning: "腫塊",
    example: "I forgot to duck, so I hit the door frame and got a big bump on my head.",
    category: "保健",
    importance: 3
  },
  {
    text: "caplet",
    meaning: "膜衣錠",
    example: "The medicine comes in easy-to-swallow caplets.",
    category: "保健",
    importance: 3
  },
  {
    text: "capsule",
    meaning: "膠囊",
    example: "There are fifty capsules in the small bottles and one hundred capsules in the large bottles.",
    category: "保健",
    importance: 3
  },
  {
    text: "cast",
    meaning: "【醫】固定用敷料",
    example: "Jack's right arm was in a plaster cast, so he couldn't write.",
    category: "保健",
    importance: 3
  },
  {
    text: "checkup",
    meaning: "身體檢查",
    example: "I go for checkups at my clinic every year.",
    category: "保健",
    importance: 3
  },
  {
    text: "clinic",
    meaning: "診所",
    example: "The dentist uses state-of-the-art technology in his clinic.",
    category: "保健",
    importance: 3
  },
  {
    text: "concern",
    meaning: "使不安；與～有關",
    example: "I was a little concerned about the pain in my arm.",
    category: "保健",
    importance: 3
  },
  {
    text: "consult",
    meaning: "求教於；諮詢；查閱（字典、參考書等）",
    example: "She consulted her doctor about her skin problem.",
    category: "保健",
    importance: 3
  },
  {
    text: "control",
    meaning: "控制",
    example: "The doctor has brought the boy's fever under control.",
    category: "保健",
    importance: 3
  },
  {
    text: "cough",
    meaning: "咳嗽",
    example: "The doctor asked me to cough while she listened to my lungs.",
    category: "保健",
    importance: 3
  },
  {
    text: "dental",
    meaning: "牙科的；牙齒的",
    example: "Good dental care is just as important as good medical care.",
    category: "保健",
    importance: 3
  },
  {
    text: "detect",
    meaning: "發現；察覺",
    example: "They have detected a problem with his blood.",
    category: "保健",
    importance: 3
  },
  {
    text: "diagnose",
    meaning: "診斷",
    example: "The woman was diagnosed with cancer.",
    category: "保健",
    importance: 3
  },
  {
    text: "diarrhea",
    meaning: "腹瀉",
    example: "My wife refuses to eat street food when we travel because she's worried about getting diarrhea.",
    category: "保健",
    importance: 3
  },
  {
    text: "disease",
    meaning: "疾病；病痛",
    example: "Leprosy is still a common disease in some countries in Africa.",
    category: "保健",
    importance: 3
  },
  {
    text: "dizzy",
    meaning: "頭暈目眩的",
    example: "I had a high fever and felt dizzy, so I went to the hospital.",
    category: "保健",
    importance: 3
  },
  {
    text: "drugstore",
    meaning: "（常兼售化妝品、日用品等的）藥房",
    example: "The drugstore around the corner is open twenty-four hours a day.",
    category: "保健",
    importance: 3
  },
  {
    text: "effective",
    meaning: "有效的；實用的",
    example: "The medicine wasn't effective, so the doctor tried a different kind.",
    category: "保健",
    importance: 3
  },
  {
    text: "emergency",
    meaning: "緊急狀況",
    example: "You should dial 911 only if there is a real medical emergency.",
    category: "保健",
    importance: 3
  },
  {
    text: "emphasize",
    meaning: "強調",
    example: "The dentist emphasized the need to brush my teeth after every meal.",
    category: "保健",
    importance: 3
  },
  {
    text: "evident",
    meaning: "明顯的",
    example: "It was evident that she had not been taking good care of herself.",
    category: "保健",
    importance: 3
  },
  {
    text: "examination room",
    meaning: "診療室",
    example: "The nurse led me into the examination room and closed the door.",
    category: "保健",
    importance: 3
  },
  {
    text: "eyedrops",
    meaning: "眼藥水",
    example: "The doctor told me to put the eyedrops in both eyes twice a day.",
    category: "保健",
    importance: 3
  },
  {
    text: "factor",
    meaning: "因素",
    example: "Smoking is a major factor of many serious illnesses.",
    category: "保健",
    importance: 3
  },
  {
    text: "finger",
    meaning: "手指",
    example: "It's going to take two months for my broken finger to heal.",
    category: "保健",
    importance: 3
  },
  {
    text: "first aid",
    meaning: "急救護理",
    example: "To qualify as a lifeguard, I have to complete a two-week course in first aid.",
    category: "保健",
    importance: 3
  },
  {
    text: "flu",
    meaning: "流行性感冒",
    example: "Most people don't understand the difference between the flu and the common cold.",
    category: "保健",
    importance: 3
  },
  {
    text: "household",
    meaning: "家庭；戶",
    example: "Thirty percent of the households in the city have two incomes.",
    category: "保健",
    importance: 3
  },
  {
    text: "hygiene",
    meaning: "衛生",
    example: "Many skin problems can be prevented through basic personal hygiene.",
    category: "保健",
    importance: 3
  },
  {
    text: "hypertension",
    meaning: "高血壓",
    example: "My father has suffered from hypertension for many years.",
    category: "保健",
    importance: 3
  },
  {
    text: "identify",
    meaning: "驗明；辨明",
    example: "I hope the clinic can identify the problem.",
    category: "保健",
    importance: 3
  },
  {
    text: "incur",
    meaning: "蒙受；招致",
    example: "Smokers incur many health problems.",
    category: "保健",
    importance: 3
  },
  {
    text: "indigestion",
    meaning: "消化不良",
    example: "Too much spicy food and coffee always gives me indigestion.",
    category: "保健",
    importance: 3
  },
  {
    text: "instruction",
    meaning: "指示",
    example: "Follow the instructions for taking this medicine.",
    category: "保健",
    importance: 3
  },
  {
    text: "instrument",
    meaning: "工具；儀器；樂器",
    example: "The dentist uses many instruments to fix teeth.",
    category: "保健",
    importance: 3
  },
  {
    text: "insurance",
    meaning: "保險",
    example: "The company offers partial-coverage health insurance.",
    category: "保健",
    importance: 3
  },
  {
    text: "itchy",
    meaning: "癢的",
    example: "The stitches will be itchy for several days, but don't scratch!",
    category: "保健",
    importance: 3
  },
  {
    text: "limit",
    meaning: "額度；限制",
    example: "Is there a limit to how much my insurance will pay out?",
    category: "保健",
    importance: 3
  },
  {
    text: "manage",
    meaning: "設法做到；處理；經營",
    example: "Did you manage to get the money back from the insurance company?",
    category: "保健",
    importance: 3
  },
  {
    text: "medicine",
    meaning: "藥；內服藥",
    example: "It's important to keep medicine in a safe place where young children can't reach it.",
    category: "保健",
    importance: 3
  },
  {
    text: "nauseous",
    meaning: "噁心的；想吐的",
    example: "The smell of rotting fish on the beach made me nauseous, and I couldn't eat my lunch.",
    category: "保健",
    importance: 3
  },
  {
    text: "needle",
    meaning: "針",
    example: "The little girl started to cry when the doctor picked up the needle from the tray.",
    category: "保健",
    importance: 3
  },
  {
    text: "nurse",
    meaning: "護士",
    example: "To call for the nurse during the night, just press this button beside your bed.",
    category: "保健",
    importance: 3
  },
  {
    text: "ointment",
    meaning: "軟膏",
    example: "The tube of ointment was past its expiry date, so I had to buy another one.",
    category: "保健",
    importance: 3
  },
  {
    text: "operate",
    meaning: "開刀",
    example: "The doctor said that he had to operate right away in order to save the patient's life.",
    category: "保健",
    importance: 3
  },
  {
    text: "optical",
    meaning: "眼睛的；視力的；光學的",
    example: "I prefer the optical mouse on my computer because it doesn't require a mouse pad.",
    category: "保健",
    importance: 3
  },
  {
    text: "organ",
    meaning: "器官",
    example: "The liver is the largest organ inside the human body.",
    category: "保健",
    importance: 3
  },
  {
    text: "overweight",
    meaning: "超重的；過重的",
    example: "My doctor told me that I was twenty pounds overweight and needed to get more exercise.",
    category: "保健",
    importance: 3
  },
  {
    text: "pain",
    meaning: "疼痛",
    example: "Cancer patients can experience a lot of pain as the disease progresses.",
    category: "保健",
    importance: 3
  },
  {
    text: "painkiller",
    meaning: "止痛劑",
    example: "The only way to get strong painkillers is with a doctor's prescription.",
    category: "保健",
    importance: 3
  },
  {
    text: "patient",
    meaning: "病人",
    example: "The emergency room was filled with patients waiting to see a doctor.",
    category: "保健",
    importance: 3
  },
  {
    text: "pediatrician",
    meaning: "小兒科醫生",
    example: "Pediatricians have to be good at calming down worried parents.",
    category: "保健",
    importance: 3
  },
  {
    text: "penicillin",
    meaning: "盤尼西林；青黴素",
    example: "Many of the new strains of bacteria are resistant to penicillin.",
    category: "保健",
    importance: 3
  },
  {
    text: "pertinent",
    meaning: "有直接關連的",
    example: "This medication is not pertinent to your health problem.",
    category: "保健",
    importance: 3
  },
  {
    text: "pharmacy",
    meaning: "藥房；配藥學",
    example: "There is a pharmacy on the first floor of the hospital.",
    category: "保健",
    importance: 3
  },
  {
    text: "physical",
    meaning: "物理學的",
    example: "The man faced years of difficult physical therapy to learn how to walk again.",
    category: "保健",
    importance: 3
  },
  {
    text: "physician",
    meaning: "醫生；內科醫生",
    example: "A good physician takes the time to listen to what the patient has to say.",
    category: "保健",
    importance: 3
  },
  {
    text: "policy",
    meaning: "保險單；政策；方針",
    example: "Your insurance policy states that you must get an official letter from your doctor.",
    category: "保健",
    importance: 3
  },
  {
    text: "potential",
    meaning: "潛力；潛能；可能性",
    example: "The doctor will tell you about the potential problem with taking this drug while working.",
    category: "保健",
    importance: 3
  },
  {
    text: "prescription",
    meaning: "處方箋；藥方",
    example: "After a doctor prescribes medicine for a patient, the patient should get the prescription filled at a pharmacy.",
    category: "保健",
    importance: 3
  },
  {
    text: "prevent",
    meaning: "防止；預防",
    example: "Brushing your teeth every day helps prevent problems later.",
    category: "保健",
    importance: 3
  },
  {
    text: "recommendation",
    meaning: "勸告；推薦；介紹",
    example: "I underwent the operation on my doctor's recommendation.",
    category: "保健",
    importance: 3
  },
  {
    text: "record",
    meaning: "記錄；記載",
    example: "Your hospital record shows your medical history.",
    category: "保健",
    importance: 3
  },
  {
    text: "recover",
    meaning: "復原",
    example: "I hope you recover from your injury soon.",
    category: "保健",
    importance: 3
  },
  {
    text: "refer",
    meaning: "轉介（病人）",
    example: "My doctor referred me to an excellent surgeon.",
    category: "保健",
    importance: 3
  },
  {
    text: "regardless",
    meaning: "無論如何",
    example: "Your insurance must cover you regardless of your medical history.",
    category: "保健",
    importance: 3
  },
  {
    text: "regularly",
    meaning: "定期地；規律地",
    example: "You must visit your dentist regularly, at least every six months.",
    category: "保健",
    importance: 3
  },
  {
    text: "restore",
    meaning: "使恢復；重建",
    example: "The medicine soon restored my health.",
    category: "保健",
    importance: 3
  },
  {
    text: "result",
    meaning: "結果；導致",
    example: "The results show that everything is normal and you have nothing to worry about.",
    category: "保健",
    importance: 3
  },
  {
    text: "sample",
    meaning: "樣本；樣品",
    example: "The nurse just needs to take a blood sample.",
    category: "保健",
    importance: 3
  },
  {
    text: "scale",
    meaning: "體重計",
    example: "The elderly woman needed help to climb up onto the scale.",
    category: "保健",
    importance: 3
  },
  {
    text: "scar",
    meaning: "疤痕",
    example: "The scar started at his knee and went all the way down to his ankle.",
    category: "保健",
    importance: 3
  },
  {
    text: "sedative",
    meaning: "鎮定劑",
    example: "The doctor gave the woman a sedative to calm her down and help her sleep.",
    category: "保健",
    importance: 3
  },
  {
    text: "serious",
    meaning: "嚴重的；危險的",
    example: "The doctor said that it's nothing serious, just a cold.",
    category: "保健",
    importance: 3
  },
  {
    text: "shoulder",
    meaning: "肩膀",
    example: "The carpenter had hurt his shoulder badly when he fell off the roof of the house.",
    category: "保健",
    importance: 3
  },
  {
    text: "side effect",
    meaning: "副作用",
    example: "One possible side effect of the drug is stomach pains.",
    category: "保健",
    importance: 3
  },
  {
    text: "sleeping pill",
    meaning: "安眠藥",
    example: "You'll need a prescription from your doctor to get a sleeping pill.",
    category: "保健",
    importance: 3
  },
  {
    text: "sneeze",
    meaning: "打噴嚏",
    example: "Cleaning up a dusty room always makes me sneeze for a couple of minutes.",
    category: "保健",
    importance: 3
  },
  {
    text: "sore",
    meaning: "（外部的）發炎疼痛",
    example: "Beth worked out for two hours last night, so she is very sore today.",
    category: "保健",
    importance: 3
  },
  {
    text: "stethoscope",
    meaning: "聽診器",
    example: "Because the nurse had a stethoscope around her neck, everyone assumed she was a doctor.",
    category: "保健",
    importance: 3
  },
  {
    text: "stomachache",
    meaning: "胃痛；腹痛",
    example: "Carol stayed in bed complaining that she had a bad stomachache.",
    category: "保健",
    importance: 3
  },
  {
    text: "stretch",
    meaning: "伸展；伸懶腰",
    example: "The jogger stopped and stretched for a minute or two before he continued running.",
    category: "保健",
    importance: 3
  },
  {
    text: "surgeon",
    meaning: "外科醫生",
    example: "The doctor called in a surgeon for a consultation on the case.",
    category: "保健",
    importance: 3
  },
  {
    text: "symptom",
    meaning: "症狀；徵候",
    example: "The nurse asked me when my symptoms first appeared.",
    category: "保健",
    importance: 3
  },
  {
    text: "syndrome",
    meaning: "併發症狀",
    example: "Children with Down syndrome have a much shorter life expectancy.",
    category: "保健",
    importance: 3
  },
  {
    text: "syrup",
    meaning: "糖漿",
    example: "This cough syrup should help your throat feel better.",
    category: "保健",
    importance: 3
  },
  {
    text: "tablet",
    meaning: "藥錠",
    example: "Take one tablet right away, and you should be feeling better soon.",
    category: "保健",
    importance: 3
  },
  {
    text: "temperature",
    meaning: "體溫",
    example: "If your temperature goes much higher, I think we should go to the emergency room.",
    category: "保健",
    importance: 3
  },
  {
    text: "therapist",
    meaning: "治療師",
    example: "The physical therapist comes twice a week to help me get used to my new prosthetic limb.",
    category: "保健",
    importance: 3
  },
  {
    text: "thermometer",
    meaning: "溫度計",
    example: "You have to keep the thermometer under your tongue for two minutes.",
    category: "保健",
    importance: 3
  },
  {
    text: "thumb",
    meaning: "拇指",
    example: "The man in the emergency room had cut his thumb, and it was bleeding badly.",
    category: "保健",
    importance: 3
  },
  {
    text: "urgent",
    meaning: "緊急的；急迫的",
    example: "Sandy needs urgent medical attention.",
    category: "保健",
    importance: 3
  },
  {
    text: "vitamin",
    meaning: "維他命",
    example: "You will not get a cold if you take vitamin C every day.",
    category: "保健",
    importance: 3
  },
  {
    text: "vomit",
    meaning: "嘔吐",
    example: "There is a special bag in the seat pocket in case you get sick and are going to vomit.",
    category: "保健",
    importance: 3
  },
  {
    text: "wind up",
    meaning: "以～結束；告終",
    example: "The doctor asked the man how he wound up with such a bruised hand.",
    category: "保健",
    importance: 3
  },
  {
    text: "X-ray",
    meaning: "X 光（片）",
    example: "The X-ray showed that the boy had broken his leg in two places.",
    category: "保健",
    importance: 3
  },
];