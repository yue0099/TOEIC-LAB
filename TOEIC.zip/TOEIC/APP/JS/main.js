
// 載入 vocabList 資料
function renderVocabCards(words) {
  const container = document.getElementById("vocabContainer");
  container.innerHTML = "";

  words.forEach(word => {
    const card = document.createElement("div");
    card.className = "bg-white border border-gray-300 rounded-lg p-4 shadow";

    card.innerHTML = `
      <h2 class="text-xl font-bold mb-2">${word.text}</h2>
      <p class="text-gray-700 mb-1">${word.meaning}</p>
      <p class="text-sm italic text-gray-600 mb-2">${word.example}</p>
      <div class="text-sm">重要程度：${"★".repeat(word.importance)}</div>
      <div class="text-sm text-gray-400">分類：${word.category}</div>
    `;

    container.appendChild(card);
  });
}

// 篩選資料
function filterVocab() {
  const category = document.getElementById("categoryFilter").value;
  const importanceValue = document.getElementById("importanceFilter").value;
  const importance = importanceValue ? parseInt(importanceValue) : null;
  const keyword = document.getElementById("keywordInput").value.trim().toLowerCase();

  const filtered = vocabList.filter(word => {
    const text = word.text.trim().toLowerCase();
    return (
      (!category || word.category === category) &&
      (!importance || word.importance === importance) &&
      (!keyword || text.startsWith(keyword))
    );
  });

  renderVocabCards(filtered);
}


CategoryOrder.forEach((cat, idx) => {
  // 先建立下拉選單選項
  const opt = document.createElement("option");
  opt.value = cat;
  opt.textContent = cat;
  categoryFilter.appendChild(opt);

  // 再建立分類卡片
  const card = document.createElement("div");
  card.className = "flex items-center bg-white p-3 rounded shadow hover:bg-blue-100 cursor-pointer";
  card.innerHTML = `
    <div class="bg-blue-500 text-white font-bold w-6 h-6 flex items-center justify-center rounded-full mr-3">${idx + 1}</div>
    <span>${cat}</span>
  `;
  card.onclick = () => {
    categoryFilter.value = cat;
    filterVocab();
  };
  categoryButtons.appendChild(card);
});

// 初始化時呼叫
populateCategories();

// 初始化事件
document.addEventListener("DOMContentLoaded", () => {
  const categorySelect = document.getElementById("categoryFilter");
  const optionExists = Array.from(categorySelect.options).some(opt => opt.value === "商務溝通");

  if (!optionExists) {
    const opt = document.createElement("option");
    opt.value = "商務溝通";
    opt.textContent = "商務溝通";
    categorySelect.appendChild(opt);
  }

  // ✅ 強制預設值為「商務溝通」，但 UI 顯示為全部主題
  categorySelect.value = "商務溝通";
  renderVocabCards(vocabList.filter(word => word.category === "商務溝通"));

  // 再設為空字串使 UI 顯示為「全部主題」
  categorySelect.value = "";
});
